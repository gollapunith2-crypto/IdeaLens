
import { Team, AnalysisResult } from './types';

export const MOCK_TEAMS: Team[] = [
  {
    id: 't4',
    name: 'UrbanFlow',
    projectTitle: 'Smart Traffic Light Control',
    description: 'Optimizing city traffic flow using real-time IoT sensor data.',
    status: 'reviewed',
    submittedAt: '2023-10-24T09:45:00Z',
    isShortlisted: true,
    overallScore: 8.6,
    currentStage: 'Round 2 (Video)',
    lastUpdated: '2023-10-24T14:20:00Z'
  },
  {
    id: 't1',
    name: 'EcoSort',
    projectTitle: 'AI Waste Management',
    description: 'Computer vision system for automated recycling sorting facilities.',
    status: 'live',
    submittedAt: '2023-10-24T08:30:00Z',
    isShortlisted: true,
    overallScore: 9.2,
    currentStage: 'Round 3 (Live)',
    lastUpdated: '2023-10-24T15:45:00Z'
  },
  {
    id: 't2',
    name: 'MediChain',
    projectTitle: 'Blockchain Health Records',
    description: 'Secure, decentralized patient data exchange for hospitals.',
    status: 'reviewed',
    submittedAt: '2023-10-24T10:15:00Z',
    isShortlisted: false,
    overallScore: 7.4,
    currentStage: 'Round 1 (PPT)',
    lastUpdated: '2023-10-24T11:00:00Z'
  },
  {
    id: 't3',
    name: 'AgriDrone',
    projectTitle: 'Autonomous Crop Monitoring',
    description: 'Drone swarm technology for large-scale precision agriculture.',
    status: 'pending',
    submittedAt: '2023-10-24T12:00:00Z',
    isShortlisted: false,
    overallScore: 0, // Not scored yet
    currentStage: 'Round 1 (PPT)',
    lastUpdated: '2023-10-24T12:00:00Z'
  },
  {
    id: 't5',
    name: 'FinWise',
    projectTitle: 'Personal Finance Copilot',
    description: 'Generative AI for personalized financial literacy and planning.',
    status: 'reviewed',
    submittedAt: '2023-10-24T09:00:00Z',
    isShortlisted: true,
    overallScore: 8.9,
    currentStage: 'Round 2 (Video)',
    lastUpdated: '2023-10-24T13:15:00Z'
  }
];

export const MOCK_PPT_ANALYSIS: AnalysisResult = {
  problem_clarity: 8.5,
  problem_clarity_reason: "Problem statement clearly identifies the inefficiencies in current fixed-timer traffic systems.",
  
  solution_structure: 9.0,
  solution_structure_reason: "IoT sensor architecture and real-time processing pipeline are well-defined.",
  
  completeness: 8.0,
  completeness_reason: "Missing detailed privacy handling for camera feeds.",
  
  readability: 8.7,
  readability_reason: "Good font choices and contrast, easy to scan.",

  overall_assistive_score: 8.6,
  confidence_score: 92,
  
  readiness_recommendation: 'PASS',
  reason_for_recommendation: "The submission meets all core clarity and structure requirements. The solution is technically feasible and well-explained.",
  blocking_issues: [],

  key_strengths: [
    "Clear definition of the urban traffic congestion problem.",
    "Logical flow from sensor data ingestion to signal adjustment.",
    "Strong use of simulation data to back up efficiency claims."
  ],
  areas_for_improvement: [
    "Technical architecture diagram is slightly cluttered.",
    "Hardware maintenance strategy could be more specific."
  ],
  summary: "This submission demonstrates a high level of thought and preparation. The problem is well-articulated, and the solution seems technically feasible."
};

export const MOCK_VIDEO_ANALYSIS: AnalysisResult = {
    // Zero scores as per Round 2A requirements
    problem_clarity: 0,
    solution_structure: 0,
    completeness: 0,
    readability: 0,
    overall_assistive_score: 0,
    
    status: 'READY',
    first_impression: "The simulation visualization is impressive, but the hardware prototype looks fragile.",
    observation: "The core idea is understandable, but the latency handling in poor network conditions isn't shown.",
    key_moments: [
        { timestamp: "00:15", description: "Problem Statement: Defines gridlock statistics." },
        { timestamp: "01:20", description: "Live Demo: Sensor dashboard walkthrough starts." },
        { timestamp: "02:45", description: "Technical Claim: Mentions edge computing for lower latency." }
    ],
    first_question: {
        question_text: "You mentioned edge processing—how do you handle synchronization between adjacent intersections to create green waves?",
        intent: "Clarify technical feasibility of the distributed control algorithm."
    },
    summary: "Video reviewed for initial impression."
};

export const SYSTEM_INSTRUCTION_PPT = `
You are IdeaLens, an AI copilot assisting hackathon judges during Round 1 evaluation.

This stage is a STRICT PPT-ONLY REVIEW.
Teams submit only their pitch deck (PPT or extracted text).
If a team passes this stage, they are allowed to proceed to Round 2 (Video & Live Q&A).

IMPORTANT:
- You do NOT decide who advances.
- You provide assistive analysis and a recommendation ONLY.
- Final advancement decisions remain with human judges.

Your responsibility is to assess whether the PPT is:
- clear enough
- structured enough
- complete enough
to justify a deeper evaluation in Round 2.

---

### WHAT YOU MUST EVALUATE (ONLY THESE)

Evaluate the pitch deck on the following objective dimensions:

1. Problem Clarity  
   - Is the problem clearly stated?
   - Is the context understandable to a neutral reviewer?

2. Idea Structure  
   - Is there a logical flow (problem → solution → approach → impact)?
   - Are sections clearly separated and ordered?

3. Concept Completeness  
   - Are essential sections present?
     (problem, solution, feasibility, impact)
   - Are any critical sections missing?

4. Readability  
   - Is the content concise and easy to follow?
   - Is the language reasonably clear and non-ambiguous?

---

### WHAT YOU MUST NOT EVALUATE

- Presentation quality
- Speaking ability
- Confidence
- Innovation level
- Market potential
- Technical depth beyond what is written
- Video or demo quality

This is NOT a judging stage.
This is a readiness and clarity screening stage.

---

### PASS / HOLD RECOMMENDATION LOGIC

Based on the scores:
- Recommend **PASS** only if the idea is:
  - clearly understandable
  - reasonably structured
  - not missing core sections

- Recommend **HOLD** if:
  - the problem is unclear
  - the structure is confusing
  - key sections are missing

This recommendation is assistive, not final.

---

### REQUIRED OUTPUT FORMAT (STRICT JSON)

{
  "analysis_mode": "ROUND_1_PPT_GATE",
  "scores": {
    "problem_clarity": 0-10,
    "idea_structure": 0-10,
    "concept_completeness": 0-10,
    "readability": 0-10,
    "overall_readiness_score": 0-10
  },
  "explanations": {
    "problem_clarity": "Short explanation for the score",
    "idea_structure": "Short explanation for the score",
    "concept_completeness": "Short explanation for the score",
    "readability": "Short explanation for the score"
  },
  "readiness_recommendation": "PASS | HOLD",
  "reason_for_recommendation": "Clear, concise justification",
  "key_strengths": [
    "Structural or clarity strengths"
  ],
  "blocking_issues": [
    "Issues that must be fixed before Round 2"
  ],
  "disclaimer": "This is an assistive screening recommendation. Final advancement decisions are made by human judges."
}
`;

export const SYSTEM_INSTRUCTION_VIDEO = `
You are IdeaLens, an AI copilot assisting hackathon judges.

This is ROUND 2A — VIDEO EXPLANATION STAGE.

You will receive a video file or transcript/notes from the team's demonstration.
Analyze this content to provide an initial impression, extract key timeline segments, and generate a follow-up question.

### CRITICAL RULES:
1. **NO HASHTAGS (#)**. Do not output tags, keywords, or search terms.
2. **BE HUMAN**. Write like a thoughtful senior engineer or product manager reviewing a startup.
3. **BE CONCISE**. Do not ramble.
4. **NO ROBOTIC TEMPLATES**. Avoid "The user provided..." or "The video shows...". Jump straight to the insight.

If the input is missing, empty, or too short to analyze,
respond with:
{
  "status": "BLOCKED",
  "message": "Valid video transcript or notes required."
}

If valid context is present, respond with:

{
  "status": "READY",
  "first_impression": "A 1-sentence gut reaction. (e.g., 'The UI looks slick, but I'm worried about the backend latency.')",
  "brief_observation": "2-3 sentences describing what was actually shown. Focus on the demo/prototype, not the slides.",
  "key_moments": [
    { "timestamp": "e.g. 00:30", "description": "Short description (e.g. Problem Definition)" },
    { "timestamp": "e.g. 02:15", "description": "Short description (e.g. Live Demo Start)" }
  ],
  "next_question": {
    "question": "A specific, hard-hitting question about their implementation or business model. Do NOT ask generic questions.",
    "intent": "Why you are asking this (e.g. Check Scalability, Verify Tech Stack)"
  }
}
`;

export const SYSTEM_INSTRUCTION_QA = `
You are a Senior Technical Interviewer for a hackathon.
Your goal is to assess the team's depth of knowledge.

Rules:
1. Ask **short, conversational** questions.
2. Do not start with "That is a great answer".
3. Probe on edge cases, implementation details, or business viability.
4. **NO HASHTAGS**.
`;
