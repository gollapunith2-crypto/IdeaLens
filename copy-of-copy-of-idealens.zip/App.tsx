import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import AdminLayout from './components/AdminLayout';
import HomeView from './components/HomeView';
import Dashboard from './components/Dashboard';
import EvaluationView from './components/EvaluationView';
import TeamsView from './components/TeamsView';
import ReportsView from './components/ReportsView';
import TeamPortalView from './components/TeamPortalView';
import { ToggleLeft, ToggleRight } from 'lucide-react';

const App: React.FC = () => {
  // Demo Mode State at App Level
  const [isDemoMode, setIsDemoMode] = useState(true);

  return (
    <HashRouter>
      {/* Toggle Demo Mode (Global Fixed) */}
      <div className="fixed bottom-4 left-4 z-[60] flex items-center gap-2 px-3 py-2 bg-slate-900/90 backdrop-blur text-white rounded-full shadow-xl border border-slate-700 cursor-pointer hover:bg-slate-900 transition-all" onClick={() => setIsDemoMode(!isDemoMode)}>
          {isDemoMode ? <ToggleRight className="text-emerald-400" /> : <ToggleLeft className="text-slate-400" />}
          <span className="text-xs font-semibold pr-1">{isDemoMode ? 'Demo Mode: ON' : 'Demo Mode: OFF'}</span>
      </div>

      <Routes>
        {/* Landing Page */}
        <Route path="/" element={<HomeView />} />

        {/* Participant Portal (Standalone) */}
        <Route path="/student/:id" element={<TeamPortalView isDemoMode={isDemoMode} />} />

        {/* Judge / Admin Portal (Layout Wrapped) */}
        <Route path="/judge" element={<AdminLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="teams" element={<TeamsView />} />
            <Route path="evaluate/:id" element={<EvaluationView isDemoMode={isDemoMode} />} />
            <Route path="reports" element={<ReportsView />} />
        </Route>

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>

    </HashRouter>
  );
};

export default App;