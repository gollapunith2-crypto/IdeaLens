import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, CartesianGrid } from 'recharts';
import { AnalysisResult } from '../types';

interface ScoreVisualizerProps {
  data: AnalysisResult;
}

const CustomTooltip = ({ active, payload, label, data }: any) => {
  if (active && payload && payload.length) {
    const scoreItem = payload[0];
    const dataItem = scoreItem.payload;
    
    return (
      <div className="bg-white p-4 rounded-xl shadow-xl border border-slate-200 max-w-xs z-50">
        <div className="flex items-center justify-between mb-2">
           <span className="font-bold text-slate-700">{dataItem.name}</span>
           <span className="font-bold text-brand-600 bg-brand-50 px-2 py-0.5 rounded text-xs">{dataItem.score}/10</span>
        </div>
        <p className="text-xs text-slate-500 leading-relaxed">
          {dataItem.reason || "AI analysis determined this score based on the submission content."}
        </p>
      </div>
    );
  }
  return null;
};

const ScoreVisualizer: React.FC<ScoreVisualizerProps> = ({ data }) => {
  const chartData = [
    { name: 'Clarity', score: data.problem_clarity, color: '#6366f1', reason: data.problem_clarity_reason },
    { name: 'Structure', score: data.solution_structure, color: '#8b5cf6', reason: data.solution_structure_reason },
    { name: 'Completeness', score: data.completeness, color: '#ec4899', reason: data.completeness_reason },
    { name: 'Readability', score: data.readability, color: '#10b981', reason: data.readability_reason },
    { name: 'Overall', score: data.overall_assistive_score, color: '#f59e0b', reason: "Aggregated score based on all metrics." },
  ];

  return (
    <div className="h-64 w-full bg-white p-4 rounded-xl shadow-sm border border-slate-100">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">AI Assessment Model</h3>
        {data.confidence_score && (
          <span className="text-[10px] font-medium px-2 py-1 rounded-full bg-slate-100 text-slate-500" title="AI Confidence Score">
             Confidence: {data.confidence_score}%
          </span>
        )}
      </div>
      <ResponsiveContainer width="100%" height="80%">
        <BarChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
          <XAxis 
            dataKey="name" 
            tick={{ fill: '#64748b', fontSize: 12 }} 
            axisLine={false} 
            tickLine={false}
          />
          <YAxis 
            hide 
            domain={[0, 10]} 
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: '#f8fafc' }} />
          <Bar dataKey="score" radius={[4, 4, 0, 0]} barSize={40}>
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ScoreVisualizer;