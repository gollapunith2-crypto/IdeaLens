import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_TEAMS } from '../constants';
import { Team } from '../types';
import { 
  CheckCircle2, Lock, AlertCircle, Clock, 
  Play, FileText, Flag, MessageSquare, 
  Shield, Zap, Search, Filter, ArrowLeft, 
  ChevronRight, BarChart2, ArrowUpRight, Award,
  Send, UserCircle, Loader2, X, Video, Save, AlertTriangle, Calendar
} from 'lucide-react';

const TeamsView: React.FC = () => {
  const navigate = useNavigate();
  const [selectedTeamId, setSelectedTeamId] = useState<string | null>(null);
  
  // -- LEVEL 1: OVERVIEW STATE --
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredTeams = useMemo(() => {
    return MOCK_TEAMS.filter(t => {
      const matchSearch = t.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.projectTitle.toLowerCase().includes(searchTerm.toLowerCase());
      const matchStatus = statusFilter === 'all' || 
                          (statusFilter === 'shortlisted' ? t.isShortlisted : t.status === statusFilter);
      return matchSearch && matchStatus;
    }).sort((a, b) => (b.overallScore || 0) - (a.overallScore || 0)); // Rank by score desc
  }, [searchTerm, statusFilter]);

  // -- LEVEL 2: DETAIL STATE --
  const selectedTeam = MOCK_TEAMS.find(t => t.id === selectedTeamId);
  const [sessionActive, setSessionActive] = useState(false);
  
  // Admin Actions State
  const [activeModal, setActiveModal] = useState<'materials' | 'notes' | 'flag' | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [savedNotes, setSavedNotes] = useState<{id: string, text: string, time: string}[]>([]);
  const [isFlagged, setIsFlagged] = useState(false);
  const [flagConfirmed, setFlagConfirmed] = useState(false);

  // Live Session State
  const [adminQuestion, setAdminQuestion] = useState('');
  const [liveTranscript, setLiveTranscript] = useState<{source: 'AI' | 'Admin', text: string}[]>([]);
  const [isEndingSession, setIsEndingSession] = useState(false);
  const [sessionFinished, setSessionFinished] = useState(false);
  const transcriptEndRef = useRef<HTMLDivElement>(null);

  // Reset state when changing teams
  useEffect(() => {
    if (selectedTeamId) {
        setSessionActive(false);
        setSessionFinished(false);
        setIsEndingSession(false);
        setAdminQuestion('');
        setActiveModal(null);
        setSavedNotes([]); // Reset notes for new team (demo)
        setIsFlagged(false);
        setFlagConfirmed(false);
    }
  }, [selectedTeamId]);

  // Initialize transcript on session start
  useEffect(() => {
    if (sessionActive && selectedTeam && !sessionFinished) {
        setLiveTranscript([
            { source: 'AI', text: `Hello ${selectedTeam.name}. Based on your video submission, could you explain how your architecture scales during peak load?` }
        ]);
    }
  }, [sessionActive, selectedTeam, sessionFinished]);

  // Scroll to bottom of transcript
  useEffect(() => {
      if (sessionActive) {
          transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }
  }, [liveTranscript, sessionActive]);

  const handleAskTeam = () => {
      if (!adminQuestion.trim()) return;
      setLiveTranscript(prev => [...prev, { source: 'Admin', text: adminQuestion }]);
      setAdminQuestion('');
  };

  const handleEndSession = async () => {
      if (isEndingSession || sessionFinished) return;
      
      setIsEndingSession(true);
      
      // Simulate score generation delay & processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setSessionFinished(true);
      setIsEndingSession(false);
      
      // Inject system message into transcript
      setLiveTranscript(prev => [
          ...prev, 
          { source: 'AI', text: "Session concluded. Final scores generated based on technical depth, clarity, and reasoning." }
      ]);

      // Update mock team status for immediate UI feedback in Level 1
      if (selectedTeam) {
          selectedTeam.status = 'reviewed'; // Mark as reviewed/completed
          selectedTeam.currentStage = 'Round 3 (Live)';
          selectedTeam.overallScore = 8.9; // Assign final score
      }
  };

  // --- Admin Action Handlers ---
  const handleSaveNote = () => {
      if (!adminNote.trim()) return;
      const newNote = {
          id: Date.now().toString(),
          text: adminNote,
          time: new Date().toLocaleString()
      };
      setSavedNotes(prev => [newNote, ...prev]);
      setAdminNote('');
  };

  const handleFlagTeam = () => {
      setIsFlagged(true);
      setFlagConfirmed(true);
      setActiveModal(null);
      // In a real app, this would trigger an API call to update status
  };

  // Helper for Detail View Icons
  const getRoundStatus = (roundNumber: number, team: Team) => {
    if (roundNumber === 1) return { status: 'COMPLETED', color: 'text-emerald-600', bg: 'bg-emerald-50', icon: CheckCircle2 };
    
    if (roundNumber === 2) {
        if (team.status === 'reviewed' || team.status === 'live') return { status: 'READY', color: 'text-indigo-600', bg: 'bg-indigo-50', icon: Clock };
        return { status: 'LOCKED', color: 'text-slate-400', bg: 'bg-slate-100', icon: Lock };
    }
    
    if (roundNumber === 3) {
        if (team.status === 'live') return { status: 'IN PROGRESS', color: 'text-rose-600', bg: 'bg-rose-50', icon: Zap };
        if (team.status === 'reviewed' && team.overallScore) return { status: 'COMPLETED', color: 'text-emerald-600', bg: 'bg-emerald-50', icon: CheckCircle2 };
        return { status: 'LOCKED', color: 'text-slate-400', bg: 'bg-slate-100', icon: Lock };
    }
    return { status: 'UNKNOWN', color: 'text-slate-400', bg: 'bg-slate-50', icon: AlertCircle };
  };

  // --------------------------------------------------------------------------
  // RENDER: LEVEL 2 - PROJECT DETAIL VIEW
  // --------------------------------------------------------------------------
  if (selectedTeamId && selectedTeam) {
    const r1 = getRoundStatus(1, selectedTeam);
    const r2 = getRoundStatus(2, selectedTeam);
    const r3 = getRoundStatus(3, selectedTeam);

    return (
      <div className="p-8 max-w-6xl mx-auto space-y-6 pb-20 animate-in slide-in-from-right-4 fade-in duration-300 relative">
        
        {/* Navigation Breadcrumb */}
        <button 
            onClick={() => setSelectedTeamId(null)}
            className="flex items-center gap-2 text-slate-500 hover:text-slate-800 font-bold text-sm transition-colors mb-2"
        >
            <ArrowLeft size={16} /> Back to Teams Overview
        </button>

        {/* 1. Header Section */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
               <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Project</span>
               <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                  {selectedTeam.currentStage || 'Round 1'}
               </span>
               {flagConfirmed && (
                   <span className="text-xs font-bold text-white bg-rose-500 px-2 py-0.5 rounded flex items-center gap-1 animate-in zoom-in">
                       <Flag size={10} fill="currentColor" /> FLAGGED FOR REVIEW
                   </span>
               )}
            </div>
            <h1 className="text-2xl font-bold text-slate-900 leading-tight">{selectedTeam.projectTitle}</h1>
            <p className="text-slate-500 font-medium flex items-center gap-2 mt-1">
               {selectedTeam.name} <span className="text-slate-300">•</span> <span className="text-xs font-mono text-slate-400">ID: {selectedTeam.id.toUpperCase()}</span>
            </p>
          </div>
          
          <div className="flex items-center gap-3">
              <div className={`px-4 py-2 rounded-lg font-bold text-sm border ${selectedTeam.isShortlisted ? 'bg-pink-50 border-pink-100 text-pink-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
                  {selectedTeam.isShortlisted ? 'Shortlisted Candidate' : 'Standard Review'}
              </div>
              <div className={`px-4 py-2 rounded-lg font-bold text-sm border ${selectedTeam.status === 'live' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-slate-50 border-slate-200 text-slate-600'}`}>
                  Status: {selectedTeam.status.toUpperCase()}
              </div>
          </div>
        </div>

        {/* 2. Submission Status Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className={`p-4 rounded-xl border border-slate-200 flex items-center gap-3 ${r1.bg}`}>
              <div className={`p-2 bg-white rounded-lg shadow-sm ${r1.color}`}><r1.icon size={20} /></div>
              <div>
                  <div className="text-xs font-bold text-slate-500 uppercase">Round 1: PPT</div>
                  <div className={`font-bold ${r1.color}`}>{r1.status}</div>
              </div>
          </div>

          <div className={`p-4 rounded-xl border border-slate-200 flex items-center gap-3 ${r2.bg}`}>
              <div className={`p-2 bg-white rounded-lg shadow-sm ${r2.color}`}><r2.icon size={20} /></div>
              <div>
                  <div className="text-xs font-bold text-slate-500 uppercase">Round 2: Video</div>
                  <div className={`font-bold ${r2.color}`}>{r2.status}</div>
              </div>
          </div>

          <div className={`p-4 rounded-xl border border-slate-200 flex items-center gap-3 ${r3.bg}`}>
              <div className={`p-2 bg-white rounded-lg shadow-sm ${r3.color}`}><r3.icon size={20} /></div>
              <div>
                  <div className="text-xs font-bold text-slate-500 uppercase">Round 3: Live Q&A</div>
                  <div className={`font-bold ${r3.color}`}>{r3.status}</div>
              </div>
          </div>
        </div>

        {/* 3. Main Evaluation / Interview Panel */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col min-h-[500px]">
           <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                  <Shield size={18} className="text-indigo-600" /> AI Interview – Admin Control
              </h3>
              <span className="text-xs font-mono text-slate-400">Session ID: {Date.now().toString().slice(-6)}</span>
           </div>
           
           <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50/50">
               {!sessionActive ? (
                   <div className="max-w-md mx-auto">
                       <div className="w-16 h-16 bg-white rounded-2xl shadow-sm border border-slate-200 flex items-center justify-center mx-auto mb-6">
                           <Play size={32} className={r2.status === 'LOCKED' ? "text-slate-300 ml-1" : "text-indigo-600 ml-1"} />
                       </div>
                       <h2 className="text-xl font-bold text-slate-900 mb-2">
                           {r2.status === 'LOCKED' ? 'Round Locked' : 'Ready to Start Interview'}
                       </h2>
                       <p className="text-slate-500 mb-8 leading-relaxed">
                           {r2.status === 'LOCKED' 
                              ? "This team must successfully complete Round 1 and Round 2 before the Live Q&A session can be initiated."
                              : "Initiate the AI-moderated technical interview. The system will ask follow-up questions based on the candidate's pitch."}
                       </p>
                       
                       <button 
                          onClick={() => setSessionActive(true)}
                          disabled={r2.status === 'LOCKED'}
                          className={`px-8 py-3 rounded-xl font-bold flex items-center justify-center gap-2 mx-auto transition-all ${
                              r2.status === 'LOCKED' 
                              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              : 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-lg shadow-indigo-200 hover:shadow-indigo-300'
                          }`}
                       >
                           {r2.status === 'LOCKED' ? <Lock size={18} /> : <Play size={18} />}
                           Start Session
                       </button>
                   </div>
               ) : (
                   <div className="w-full h-full flex flex-col items-center justify-center animate-in fade-in zoom-in duration-300">
                       <div className="bg-white p-6 rounded-2xl shadow-xl border border-indigo-100 max-w-lg w-full text-left relative overflow-hidden flex flex-col h-full max-h-[600px]">
                           
                           {/* Active Status Header */}
                           <div className={`absolute top-0 left-0 w-full h-1 z-10 ${sessionFinished ? 'bg-emerald-500' : 'bg-indigo-500 animate-pulse'}`} />
                           <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                               <div className="flex items-center gap-2">
                                   <div className={`w-2 h-2 rounded-full ${sessionFinished ? 'bg-emerald-500' : 'bg-rose-500 animate-pulse'}`} />
                                   <span className={`text-xs font-bold uppercase tracking-wider ${sessionFinished ? 'text-emerald-500' : 'text-rose-500'}`}>
                                       {sessionFinished ? 'Session Completed' : 'Live Session Active'}
                                   </span>
                               </div>
                               <h3 className="font-bold text-slate-800 text-sm">AI Interviewer</h3>
                           </div>

                           {/* Transcript Area */}
                           <div className="flex-1 overflow-y-auto mb-6 space-y-4 pr-2 max-h-[300px] border border-slate-100 rounded-xl p-4 bg-slate-50/50">
                               {liveTranscript.map((item, index) => (
                                   <div key={index} className="flex flex-col gap-1">
                                       {item.source === 'Admin' && (
                                           <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-700 mb-0.5">
                                               <UserCircle size={12} /> Judge (Admin):
                                           </div>
                                       )}
                                       <p className={`text-sm leading-relaxed p-3 rounded-lg border ${
                                           item.source === 'AI' 
                                           ? 'bg-white text-slate-600 border-slate-100 italic' 
                                           : 'bg-indigo-50 text-indigo-900 border-indigo-100 font-medium'
                                       }`}>
                                           "{item.text}"
                                       </p>
                                   </div>
                               ))}
                               <div ref={transcriptEndRef} />
                           </div>

                           {/* Admin Question Input OR Success Message */}
                           <div className="mb-6 pt-4 border-t border-slate-100">
                               {sessionFinished ? (
                                   <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-6 text-center animate-in zoom-in duration-300">
                                       <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-3">
                                           <CheckCircle2 className="text-emerald-600" size={24} />
                                       </div>
                                       <h3 className="text-emerald-800 font-bold mb-1">Interview Completed</h3>
                                       <p className="text-emerald-600 text-sm">Final scores have been generated and saved to the team record.</p>
                                   </div>
                               ) : (
                                   <>
                                       <label className="text-xs font-bold text-slate-900 uppercase mb-2 block flex items-center gap-2">
                                           <MessageSquare size={12} className="text-indigo-600" /> Admin Question
                                       </label>
                                       <div className="relative">
                                            <textarea 
                                                className="w-full h-20 p-3 rounded-lg border border-slate-300 text-sm text-slate-900 placeholder:text-slate-400 focus:ring-2 focus:ring-indigo-500 outline-none resize-none bg-white pr-12 shadow-sm disabled:opacity-50 disabled:bg-slate-50"
                                                placeholder="Type a custom question to ask the team..."
                                                maxLength={300}
                                                value={adminQuestion}
                                                onChange={(e) => setAdminQuestion(e.target.value)}
                                                disabled={isEndingSession}
                                                onKeyDown={(e) => {
                                                    if (e.key === 'Enter' && !e.shiftKey) {
                                                        e.preventDefault();
                                                        handleAskTeam();
                                                    }
                                                }}
                                            />
                                            <button 
                                                onClick={handleAskTeam}
                                                disabled={!adminQuestion.trim() || isEndingSession}
                                                className="absolute right-2 bottom-2 p-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:bg-slate-300"
                                                title="Ask Team"
                                            >
                                                <Send size={16} />
                                            </button>
                                       </div>
                                   </>
                               )}
                           </div>

                           {/* Controls */}
                           <div className="flex gap-2 mt-auto">
                               <button 
                                    onClick={() => setSessionActive(false)} 
                                    disabled={isEndingSession || sessionFinished}
                                    className="flex-1 py-3 border border-slate-300 rounded-xl text-slate-600 font-bold text-sm hover:bg-slate-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                   Pause Session
                               </button>
                               <button 
                                    onClick={handleEndSession}
                                    disabled={isEndingSession || sessionFinished}
                                    className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg ${
                                        sessionFinished 
                                        ? 'bg-emerald-50 text-emerald-600 border border-emerald-200 shadow-none' 
                                        : 'bg-rose-600 text-white hover:bg-rose-700 shadow-rose-200'
                                    } disabled:opacity-75 disabled:cursor-not-allowed`}
                                >
                                   {isEndingSession ? (
                                       <><Loader2 className="animate-spin" size={16} /> Generating Scores...</>
                                   ) : sessionFinished ? (
                                       <><CheckCircle2 size={16} /> Session Closed</>
                                   ) : (
                                       "End & Score"
                                   )}
                               </button>
                           </div>

                       </div>
                   </div>
               )}
           </div>
        </div>

        {/* 4. Admin Actions Section */}
        <div className="flex items-center gap-4">
            <button 
                onClick={() => setActiveModal('materials')}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-50 shadow-sm transition-colors"
            >
                <FileText size={16} /> View Submitted Materials
            </button>
            <button 
              onClick={() => setActiveModal('notes')}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-50 shadow-sm transition-colors"
            >
                <MessageSquare size={16} /> Add Admin Note
            </button>
            <button 
                onClick={() => setActiveModal('flag')}
                disabled={flagConfirmed}
                className={`flex items-center gap-2 px-4 py-2 border rounded-lg text-sm font-bold shadow-sm transition-colors ml-auto ${
                    flagConfirmed 
                    ? 'bg-rose-50 border-rose-100 text-rose-400 cursor-not-allowed' 
                    : 'bg-white border-slate-200 text-rose-600 hover:bg-rose-50 hover:border-rose-200'
                }`}
            >
                <Flag size={16} /> {flagConfirmed ? 'Flagged for Review' : 'Flag for Manual Review'}
            </button>
        </div>

        {/* MODALS OVERLAY */}
        {activeModal && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
                
                {/* MATERIALS MODAL */}
                {activeModal === 'materials' && (
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                            <div>
                                <h3 className="text-lg font-bold text-slate-900">Submitted Materials</h3>
                                <p className="text-sm text-slate-500">ReadOnly Access • {selectedTeam.projectTitle}</p>
                            </div>
                            <button onClick={() => setActiveModal(null)} className="p-2 hover:bg-slate-200 rounded-full transition-colors"><X size={20} className="text-slate-500" /></button>
                        </div>
                        <div className="flex-1 overflow-auto p-6 bg-slate-100 grid grid-cols-1 md:grid-cols-2 gap-6">
                             {/* Description */}
                             <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                                 <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><FileText size={18} className="text-indigo-600"/> Project Context</h4>
                                 <p className="text-sm text-slate-600 leading-relaxed">{selectedTeam.description}</p>
                             </div>

                             {/* Media Column */}
                             <div className="space-y-6">
                                 {/* PPT Placeholder */}
                                 <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                                     <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><FileText size={18} className="text-rose-500"/> Pitch Deck</h4>
                                     <div className="aspect-[4/3] bg-slate-100 rounded-lg border border-slate-200 flex flex-col items-center justify-center text-slate-400">
                                         <FileText size={48} className="mb-2 opacity-50" />
                                         <span className="text-xs font-bold uppercase">Preview Unavailable</span>
                                         <span className="text-[10px]">PDF Viewer Placeholder</span>
                                     </div>
                                 </div>
                                 {/* Video Placeholder */}
                                 <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                                     <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Video size={18} className="text-emerald-500"/> Demo Video</h4>
                                     <div className="aspect-video bg-black rounded-lg border border-slate-900 flex items-center justify-center relative overflow-hidden group cursor-pointer">
                                         <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm group-hover:scale-110 transition-transform">
                                             <Play size={20} className="text-white ml-1" />
                                         </div>
                                     </div>
                                 </div>
                             </div>
                        </div>
                        <div className="p-4 border-t border-slate-200 bg-white text-right">
                             <button onClick={() => setActiveModal(null)} className="px-6 py-2 bg-slate-900 text-white rounded-lg text-sm font-bold hover:bg-slate-800">Close Viewer</button>
                        </div>
                    </div>
                )}

                {/* NOTES MODAL */}
                {activeModal === 'notes' && (
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200">
                        <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-amber-50">
                            <div>
                                <h3 className="text-lg font-bold text-amber-900">Admin Notes</h3>
                                <p className="text-sm text-amber-700">Internal use only • Not visible to teams</p>
                            </div>
                            <button onClick={() => setActiveModal(null)} className="p-2 hover:bg-amber-100 rounded-full transition-colors"><X size={20} className="text-amber-700" /></button>
                        </div>
                        <div className="p-6 space-y-4">
                            <textarea 
                                className="w-full h-32 p-4 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 outline-none resize-none"
                                placeholder="Write a confidential note..."
                                value={adminNote}
                                onChange={(e) => setAdminNote(e.target.value)}
                            />
                            <div className="flex justify-between items-center">
                                <span className="text-xs text-slate-400">{savedNotes.length} notes saved</span>
                                <button 
                                    onClick={handleSaveNote}
                                    disabled={!adminNote.trim()}
                                    className="px-4 py-2 bg-amber-600 text-white rounded-lg text-sm font-bold hover:bg-amber-700 disabled:opacity-50 flex items-center gap-2"
                                >
                                    <Save size={16} /> Save Note
                                </button>
                            </div>
                            
                            {/* History */}
                            {savedNotes.length > 0 && (
                                <div className="mt-6 pt-4 border-t border-slate-100 max-h-48 overflow-y-auto space-y-3">
                                    <h4 className="text-xs font-bold text-slate-500 uppercase">Previous Notes</h4>
                                    {savedNotes.map((note) => (
                                        <div key={note.id} className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                                            <p className="text-sm text-slate-700 mb-1">{note.text}</p>
                                            <div className="flex items-center gap-1 text-[10px] text-slate-400">
                                                <Calendar size={10} /> {note.time}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* FLAG MODAL */}
                {activeModal === 'flag' && (
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200 text-center p-6">
                        <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <AlertTriangle className="text-rose-600" size={24} />
                        </div>
                        <h3 className="text-lg font-bold text-slate-900 mb-2">Flag for Manual Review?</h3>
                        <p className="text-sm text-slate-500 mb-6">
                            This will pause automated processing and mark the project "FLAGGED_FOR_MANUAL_REVIEW". This action is visible to all admins.
                        </p>
                        <div className="flex gap-3">
                            <button 
                                onClick={() => setActiveModal(null)}
                                className="flex-1 py-2.5 border border-slate-300 rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-50"
                            >
                                Cancel
                            </button>
                            <button 
                                onClick={handleFlagTeam}
                                className="flex-1 py-2.5 bg-rose-600 text-white rounded-lg text-sm font-bold hover:bg-rose-700 shadow-lg shadow-rose-200"
                            >
                                Confirm Flag
                            </button>
                        </div>
                    </div>
                )}

            </div>
        )}

        {/* 6. Footer State Indicator */}
        <div className="fixed bottom-0 left-64 right-0 p-2 bg-slate-900 text-slate-400 text-[10px] uppercase font-bold tracking-widest text-center z-10">
            Demo Mode Active • Actions are Simulated
        </div>

      </div>
    );
  }

  // --------------------------------------------------------------------------
  // RENDER: LEVEL 1 - TEAMS OVERVIEW LIST (DEFAULT)
  // --------------------------------------------------------------------------
  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="flex items-end justify-between">
            <div>
                <div className="flex items-center gap-4 mb-1">
                     <button 
                        onClick={() => navigate('/judge')}
                        className="flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 font-bold text-sm hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-sm"
                    >
                        <ArrowLeft size={16} /> Back
                    </button>
                    <h1 className="text-3xl font-bold text-slate-900">Evaluation Queue</h1>
                </div>
                <p className="text-slate-500 mt-1">Select a team to begin detailed review and interviewing.</p>
            </div>
            <div className="text-right">
                <div className="text-2xl font-bold text-indigo-600">{filteredTeams.length}</div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Teams</div>
            </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input 
                    type="text" 
                    placeholder="Search by team or project name..." 
                    className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <div className="relative w-full md:w-64">
                <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <select 
                    className="w-full pl-10 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none appearance-none cursor-pointer"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                >
                    <option value="all">Show All Statuses</option>
                    <option value="pending">Pending Review</option>
                    <option value="reviewed">Reviewed</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="live">Live Now</option>
                </select>
                <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 rotate-90" size={14} />
            </div>
        </div>

        {/* List Header */}
        <div className="grid grid-cols-12 px-6 py-2 bg-slate-100/50 rounded-lg border border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            <div className="col-span-1 text-center">Rank</div>
            <div className="col-span-4">Project & Team</div>
            <div className="col-span-3">Round Status</div>
            <div className="col-span-2 text-center">Score</div>
            <div className="col-span-2 text-right">Action</div>
        </div>

        {/* List Body */}
        <div className="space-y-2">
            {filteredTeams.length === 0 && (
                <div className="p-12 text-center bg-white rounded-xl border border-slate-200 border-dashed">
                    <p className="text-slate-400 font-medium">No teams match your search criteria.</p>
                </div>
            )}

            {filteredTeams.map((team, index) => (
                <div 
                    key={team.id} 
                    className="grid grid-cols-12 px-6 py-4 bg-white rounded-xl border border-slate-200 shadow-sm items-center hover:border-indigo-300 hover:shadow-md transition-all group"
                >
                    {/* Rank */}
                    <div className="col-span-1 text-center">
                        <span className={`inline-block w-8 h-8 leading-8 rounded-full font-bold text-xs ${index < 3 ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500'}`}>
                            #{index + 1}
                        </span>
                    </div>

                    {/* Team Info */}
                    <div className="col-span-4">
                        <div className="font-bold text-slate-900 text-base mb-1">{team.projectTitle}</div>
                        <div className="text-xs text-slate-500 flex items-center gap-2">
                            <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 font-medium">{team.name}</span>
                            {team.isShortlisted && (
                                <span className="text-pink-600 flex items-center gap-1 font-bold">
                                    <Award size={10} /> Shortlisted
                                </span>
                            )}
                        </div>
                    </div>

                    {/* Status */}
                    <div className="col-span-3">
                         <div className="flex flex-col items-start gap-1">
                             <div className={`text-xs font-bold px-2 py-1 rounded border uppercase tracking-wider ${
                                team.status === 'live' ? 'bg-rose-50 border-rose-100 text-rose-700' :
                                team.status === 'reviewed' ? 'bg-emerald-50 border-emerald-100 text-emerald-700' :
                                'bg-slate-50 border-slate-200 text-slate-600'
                             }`}>
                                 {team.status}
                             </div>
                             <span className="text-[10px] text-slate-400 font-mono">
                                 Current: {team.currentStage}
                             </span>
                         </div>
                    </div>

                    {/* Score */}
                    <div className="col-span-2 flex justify-center">
                         {team.overallScore ? (
                             <div className="text-center">
                                 <div className="font-bold text-slate-900 text-lg">{team.overallScore}</div>
                                 <div className="h-1 w-12 bg-slate-100 rounded-full overflow-hidden mt-1">
                                     <div 
                                        className="h-full bg-indigo-500" 
                                        style={{ width: `${(team.overallScore / 10) * 100}%` }} 
                                     />
                                 </div>
                             </div>
                         ) : (
                             <span className="text-slate-300 text-xs italic">--</span>
                         )}
                    </div>

                    {/* Action */}
                    <div className="col-span-2 text-right">
                        <button 
                            onClick={() => setSelectedTeamId(team.id)}
                            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-700 rounded-lg text-sm font-bold border border-slate-200 group-hover:bg-indigo-600 group-hover:text-white group-hover:border-indigo-600 transition-colors"
                        >
                            Open Evaluation <ArrowUpRight size={16} />
                        </button>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
};

export default TeamsView;