
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_TEAMS } from '../constants';
import { 
    ChevronRight, Clock, CheckCircle2, Radio, Search, Filter, Heart, 
    ArrowUp, ArrowDown, Activity, Award, BarChart2, Zap 
} from 'lucide-react';
import { Team } from '../types';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'score' | 'time' | 'stage'>('score');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // --- Calculations ---

  // 1. Filter
  const filteredTeams = useMemo(() => {
      return MOCK_TEAMS.filter(team => {
          const matchesSearch = team.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                team.projectTitle.toLowerCase().includes(searchTerm.toLowerCase());
          const matchesFilter = statusFilter === 'all' || 
                                (statusFilter === 'shortlist' ? team.isShortlisted : team.status === statusFilter);
          return matchesSearch && matchesFilter;
      });
  }, [searchTerm, statusFilter]);

  // 2. Sort & Rank
  const sortedAndRankedTeams = useMemo(() => {
      const sorted = [...filteredTeams].sort((a, b) => {
          if (sortBy === 'score') {
              return sortOrder === 'asc' 
                  ? (a.overallScore || 0) - (b.overallScore || 0)
                  : (b.overallScore || 0) - (a.overallScore || 0);
          } else if (sortBy === 'time') {
              const dateA = new Date(a.lastUpdated || a.submittedAt).getTime();
              const dateB = new Date(b.lastUpdated || b.submittedAt).getTime();
              return sortOrder === 'asc' ? dateA - dateB : dateB - dateA;
          } else if (sortBy === 'stage') {
              const stageA = a.currentStage || '';
              const stageB = b.currentStage || '';
              return sortOrder === 'asc' ? stageA.localeCompare(stageB) : stageB.localeCompare(stageA);
          }
          return 0;
      });

      // Calculate Rank (only relevant if sorting by score desc)
      return sorted.map((team, index) => ({
          ...team,
          // If sorted by score desc, rank is index + 1, else undefined/dash
          rank: (sortBy === 'score' && sortOrder === 'desc') ? index + 1 : '-' 
      }));
  }, [filteredTeams, sortBy, sortOrder]);

  const toggleSort = (field: 'score' | 'time' | 'stage') => {
      if (sortBy === field) {
          setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc');
      } else {
          setSortBy(field);
          setSortOrder('desc');
      }
  };

  const getTimeAgo = (dateStr: string) => {
      const diff = Date.now() - new Date(dateStr).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 60) return `${mins}m ago`;
      const hours = Math.floor(mins / 60);
      if (hours < 24) return `${hours}h ago`;
      return `${Math.floor(hours / 24)}d ago`;
  };

  // Vertical Score Bars (Signal Strength Style)
  const ScoreBars = ({ score }: { score: number }) => {
      const level = score >= 9 ? 4 : score >= 7 ? 3 : score >= 5 ? 2 : score > 0 ? 1 : 0;
      return (
          <div className="flex items-end gap-1 h-6" title={`Score: ${score}/10`}>
              <div className={`w-1.5 rounded-sm transition-all duration-300 ${level >= 1 ? 'h-2 bg-rose-400' : 'h-2 bg-slate-200'}`} />
              <div className={`w-1.5 rounded-sm transition-all duration-300 ${level >= 2 ? 'h-3 bg-amber-400' : 'h-3 bg-slate-200'}`} />
              <div className={`w-1.5 rounded-sm transition-all duration-300 ${level >= 3 ? 'h-4 bg-lime-400' : 'h-4 bg-slate-200'}`} />
              <div className={`w-1.5 rounded-sm transition-all duration-300 ${level >= 4 ? 'h-5 bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'h-5 bg-slate-200'}`} />
          </div>
      );
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8 flex justify-between items-end">
        <div>
            <h2 className="text-3xl font-bold text-slate-900">Judge Dashboard</h2>
            <p className="text-slate-500 mt-2">Evaluation queue, real-time status, and internal rankings.</p>
        </div>
        <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full border border-indigo-100 text-xs font-bold animate-in fade-in">
                 <Zap size={12} className="fill-indigo-700" /> Demo Mode Active
             </div>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4">
             <div className="bg-slate-100 p-3 rounded-lg"><Clock size={24} className="text-slate-500" /></div>
             <div>
                <div className="text-slate-500 text-xs font-bold uppercase tracking-wide">Queue</div>
                <div className="text-2xl font-bold text-slate-900">{MOCK_TEAMS.filter(t => t.status === 'pending').length}</div>
             </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4">
             <div className="bg-emerald-50 p-3 rounded-lg"><Radio size={24} className="text-emerald-500" /></div>
             <div>
                <div className="text-slate-500 text-xs font-bold uppercase tracking-wide">Live Now</div>
                <div className="text-2xl font-bold text-emerald-600">{MOCK_TEAMS.filter(t => t.status === 'live').length}</div>
             </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4">
             <div className="bg-pink-50 p-3 rounded-lg"><Heart size={24} className="text-pink-500" /></div>
             <div>
                <div className="text-slate-500 text-xs font-bold uppercase tracking-wide">Shortlisted</div>
                <div className="text-2xl font-bold text-pink-600">{MOCK_TEAMS.filter(t => t.isShortlisted).length}</div>
             </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex items-center gap-4">
             <div className="bg-indigo-50 p-3 rounded-lg"><BarChart2 size={24} className="text-indigo-500" /></div>
             <div>
                <div className="text-slate-500 text-xs font-bold uppercase tracking-wide">Avg Score</div>
                <div className="text-2xl font-bold text-indigo-600">7.8</div>
             </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col min-h-[500px]">
        {/* Toolbar */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="flex items-center gap-3">
              <button 
                  onClick={() => toggleSort('score')} 
                  className={`flex items-center gap-1 text-xs font-bold px-3 py-2 rounded-lg transition-colors ${sortBy === 'score' ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
              >
                  Overall Score {sortBy === 'score' && (sortOrder === 'desc' ? <ArrowDown size={12} /> : <ArrowUp size={12} />)}
              </button>
              <button 
                  onClick={() => toggleSort('time')} 
                  className={`flex items-center gap-1 text-xs font-bold px-3 py-2 rounded-lg transition-colors ${sortBy === 'time' ? 'bg-indigo-100 text-indigo-700' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
              >
                  Review Time {sortBy === 'time' && (sortOrder === 'desc' ? <ArrowDown size={12} /> : <ArrowUp size={12} />)}
              </button>
          </div>
          
          <div className="flex items-center gap-3 w-full md:w-auto">
             <div className="relative group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={16} />
                <input 
                  type="text" 
                  placeholder="Search teams..." 
                  className="pl-9 pr-4 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:outline-none w-full md:w-64 transition-all"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
             </div>
             <div className="relative">
                <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <select 
                   className="pl-9 pr-8 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none appearance-none bg-white cursor-pointer hover:bg-slate-50 transition-colors"
                   value={statusFilter}
                   onChange={(e) => setStatusFilter(e.target.value)}
                >
                    <option value="all">All Teams</option>
                    <option value="pending">Review Queue</option>
                    <option value="reviewed">Evaluated</option>
                    <option value="live">Live Now</option>
                    <option value="shortlist">Shortlisted</option>
                </select>
             </div>
          </div>
        </div>

        {/* List Header */}
        <div className="grid grid-cols-12 px-6 py-3 bg-slate-50/50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
            <div className="col-span-1 text-center">Rank</div>
            <div className="col-span-4">Team & Project</div>
            <div className="col-span-3">Status & Stage</div>
            <div className="col-span-2 text-center">AI Score</div>
            <div className="col-span-2 text-right">Updated</div>
        </div>

        {/* List Body */}
        <div className="divide-y divide-slate-100 bg-white">
          {sortedAndRankedTeams.length === 0 && (
              <div className="p-12 text-center flex flex-col items-center">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                      <Search className="text-slate-400" size={24} />
                  </div>
                  <h3 className="text-slate-900 font-bold">No teams found</h3>
                  <p className="text-slate-500 text-sm">Try adjusting filters or search terms.</p>
              </div>
          )}
          
          {sortedAndRankedTeams.map((team) => (
            <div 
              key={team.id} 
              onClick={() => navigate(`/judge/evaluate/${team.id}`)}
              className="grid grid-cols-12 px-6 py-4 items-center hover:bg-slate-50 cursor-pointer transition-colors group"
            >
              {/* Rank */}
              <div className="col-span-1 text-center">
                  {typeof team.rank === 'number' ? (
                      <span className={`inline-block w-8 h-8 leading-8 rounded-full font-bold text-xs ${team.rank <= 3 ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500'}`}>
                          #{team.rank}
                      </span>
                  ) : (
                      <span className="text-slate-300 font-mono text-xs">-</span>
                  )}
              </div>

              {/* Team Info */}
              <div className="col-span-4 pr-4">
                  <div className="font-bold text-slate-900 text-sm mb-0.5 group-hover:text-indigo-600 transition-colors">
                      {team.projectTitle}
                  </div>
                  <div className="text-xs text-slate-500 flex items-center gap-1.5">
                      <span className="font-medium text-slate-600">{team.name}</span>
                  </div>
              </div>

              {/* Status & Stage */}
              <div className="col-span-3 flex flex-col items-start gap-1.5">
                  <div className="flex gap-2">
                    {team.status === 'live' && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-white bg-red-500 px-2 py-0.5 rounded-full uppercase tracking-wider animate-pulse shadow-sm shadow-red-200">
                           <Radio size={10} /> Live
                        </span>
                    )}
                    {team.isShortlisted && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-white bg-pink-500 px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm shadow-pink-200">
                           <Award size={10} /> Top Pick
                        </span>
                    )}
                    {team.status === 'reviewed' && !team.isShortlisted && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-full uppercase tracking-wider border border-slate-200">
                           Evaluated
                        </span>
                    )}
                    {team.status === 'pending' && (
                        <span className="flex items-center gap-1 text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full uppercase tracking-wider border border-amber-100">
                           Awaiting
                        </span>
                    )}
                  </div>
                  <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">
                      {team.currentStage || 'Pre-Round 1'}
                  </div>
              </div>

              {/* Score Bar */}
              <div className="col-span-2 flex flex-col items-center justify-center">
                  {team.overallScore !== undefined && team.overallScore > 0 ? (
                      <>
                        <ScoreBars score={team.overallScore} />
                      </>
                  ) : (
                      <span className="text-xs text-slate-300 italic">Not Scored</span>
                  )}
              </div>

              {/* Timestamp */}
              <div className="col-span-2 text-right">
                  <div className="flex items-center justify-end gap-1 text-xs text-slate-500">
                      <Clock size={12} className="text-slate-300" />
                      {getTimeAgo(team.lastUpdated || team.submittedAt)}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                      {new Date(team.lastUpdated || team.submittedAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                  </div>
              </div>

              {/* Hover Chevron */}
              <div className="absolute right-4 opacity-0 group-hover:opacity-100 transition-opacity text-slate-300">
                  <ChevronRight size={20} />
              </div>

            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
