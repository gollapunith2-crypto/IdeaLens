import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MOCK_TEAMS } from '../constants';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell 
} from 'recharts';
import { 
  Users, 
  CheckCircle2, 
  Award, 
  TrendingUp, 
  Share2, 
  Printer, 
  AlertTriangle,
  BrainCircuit,
  ArrowLeft
} from 'lucide-react';
import { jsPDF } from 'jspdf';

const ReportsView: React.FC = () => {
  const navigate = useNavigate();
  const [isExporting, setIsExporting] = useState(false);

  // --- Calculations ---
  const totalTeams = MOCK_TEAMS.length;
  const evaluatedCount = MOCK_TEAMS.filter(t => t.status === 'reviewed' || t.status === 'live').length;
  const shortlistedCount = MOCK_TEAMS.filter(t => t.isShortlisted).length;
  
  // Mock Data for Charts
  const chartData = [
      { name: 'Clarity', score: 8.5, color: '#6366f1' },
      { name: 'Structure', score: 7.2, color: '#8b5cf6' },
      { name: 'Tech', score: 6.9, color: '#ec4899' },
      { name: 'Impact', score: 8.8, color: '#10b981' },
  ];

  // --- Actions ---
  const handleExportPDF = () => {
    setIsExporting(true);
    
    try {
        const doc = new jsPDF();
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const margin = 20;
        let y = 20;

        // Helper for Text
        const addText = (text: string, fontSize: number = 10, isBold: boolean = false, color: string = '#000000') => {
            doc.setFontSize(fontSize);
            doc.setTextColor(color);
            doc.setFont("helvetica", isBold ? "bold" : "normal");
            const lines = doc.splitTextToSize(text, pageWidth - (margin * 2));
            doc.text(lines, margin, y);
            y += (lines.length * fontSize * 0.4) + 6;
        };

        // 1. HEADER
        addText("Hackathon Analytics Report", 22, true);
        addText(`Generated on: ${new Date().toLocaleString()}`, 10, false, '#666666');
        
        y += 5;
        doc.setDrawColor(200, 200, 200);
        doc.line(margin, y, pageWidth - margin, y);
        y += 10;

        // 2. HACKATHON SUMMARY
        addText("1. Hackathon Summary", 14, true);
        addText(`Total Teams Participated: ${totalTeams}`);
        addText(`Teams Evaluated: ${evaluatedCount}`);
        addText(`Teams Shortlisted: ${shortlistedCount}`);
        addText(`Average Score: 7.8`);
        y += 10;

        // 3. EVALUATION BREAKDOWN
        addText("2. Evaluation Breakdown", 14, true);
        const round1 = MOCK_TEAMS.filter(t => t.currentStage?.includes('Round 1')).length;
        const round2 = MOCK_TEAMS.filter(t => t.currentStage?.includes('Round 2')).length;
        const round3 = MOCK_TEAMS.filter(t => t.currentStage?.includes('Round 3')).length;
        
        addText(`Round 1 (PPT Phase): ${round1} teams`);
        addText(`Round 2 (Video Phase): ${round2} teams`);
        addText(`Round 3 (Live Q&A): ${round3} teams`);
        y += 10;

        // 4. AI INSIGHTS
        addText("3. AI Strategic Insights", 14, true);
        const insights = [
            "Technical depth scores are lower than average (6.9), indicating teams focused more on business pitches.",
            "Teams providing video demos had a 40% higher shortlist rate compared to those who only submitted slides.",
            "A common gap identified was the lack of detailed monetization strategies in 3 out of 5 submissions."
        ];
        insights.forEach(text => {
             const lines = doc.splitTextToSize(`• ${text}`, pageWidth - margin - 25);
             doc.text(lines, margin + 5, y);
             y += (lines.length * 5) + 4;
        });
        y += 10;

        // 5. TEAM TABLE
        if (y > pageHeight - 60) {
            doc.addPage();
            y = 20;
        }

        addText("4. Team Evaluation Detail", 14, true);
        
        // Headers
        const headers = ["Team Name", "Project Title", "Status", "Score", "Date"];
        const colWidths = [40, 60, 30, 20, 30];
        let x = margin;
        
        // Header Row Background
        doc.setFillColor(241, 245, 249); // slate-100
        doc.rect(margin, y - 5, pageWidth - (margin * 2), 8, 'F');
        
        doc.setFont("helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(0, 0, 0);
        
        headers.forEach((h, i) => {
            doc.text(h, x, y);
            x += colWidths[i];
        });
        y += 8;

        // Rows
        doc.setFont("helvetica", "normal");
        doc.setTextColor(51, 65, 85); // slate-700
        
        MOCK_TEAMS.forEach(team => {
            if (y > pageHeight - 20) {
                doc.addPage();
                y = 20;
                 // Re-draw header on new page
                doc.setFont("helvetica", "bold");
                doc.setFillColor(241, 245, 249);
                doc.rect(margin, y - 5, pageWidth - (margin * 2), 8, 'F');
                let hx = margin;
                headers.forEach((h, i) => {
                    doc.text(h, hx, y);
                    hx += colWidths[i];
                });
                doc.setFont("helvetica", "normal");
                y += 8;
            }

            x = margin;
            doc.text(team.name, x, y);
            x += colWidths[0];

            let title = team.projectTitle;
            if (title.length > 30) title = title.substring(0, 27) + "...";
            doc.text(title, x, y);
            x += colWidths[1];

            doc.text(team.status.toUpperCase(), x, y);
            x += colWidths[2];

            doc.text(team.overallScore ? team.overallScore.toString() : "-", x, y);
            x += colWidths[3];

            doc.text(new Date(team.submittedAt).toLocaleDateString(), x, y);
            
            y += 7;
            doc.setDrawColor(226, 232, 240); // slate-200
            doc.line(margin, y - 5, pageWidth - margin, y - 5);
        });

        // Page Numbers Footer
        const pageCount = doc.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i);
            doc.setFontSize(8);
            doc.setTextColor(148, 163, 184); // slate-400
            doc.text(`Page ${i} of ${pageCount}`, pageWidth / 2, pageHeight - 10, { align: 'center' });
        }

        doc.save("Hackathon_Analytics_Report.pdf");

    } catch (e) {
        console.error(e);
        alert("Export failed");
    } finally {
        setIsExporting(false);
    }
  };

  const handleExportCSV = () => {
      const csvContent = "data:text/csv;charset=utf-8,Team,Status,Shortlisted\n" 
          + MOCK_TEAMS.map(t => `${t.name},${t.status},${t.isShortlisted}`).join("\n");
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.href = encodedUri;
      link.download = "teams.csv";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8 bg-slate-50 min-h-screen">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-6">
        <div className="flex items-start gap-4">
            <button 
                onClick={() => navigate('/judge')}
                className="mt-1 flex items-center gap-2 px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-slate-500 font-bold text-sm hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-sm"
            >
                <ArrowLeft size={16} /> Back
            </button>
            <div>
                <h1 className="text-3xl font-bold text-slate-900">Analytics Report</h1>
                <p className="text-slate-500 mt-1">Overview of hackathon metrics and performance.</p>
            </div>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={handleExportCSV}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium hover:bg-slate-50"
            >
                <Share2 size={16} /> CSV
            </button>
            <button 
                onClick={handleExportPDF}
                disabled={isExporting}
                className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-medium hover:bg-slate-800"
            >
                <Printer size={16} /> {isExporting ? "Generating..." : "Download Report"}
            </button>
        </div>
      </div>

      {/* Visual Report Area */}
      <div className="space-y-8 bg-slate-50 p-1">
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                      <span className="text-slate-500 text-sm font-medium">Total Teams</span>
                      <Users className="text-blue-500" size={20} />
                  </div>
                  <div className="text-3xl font-bold text-slate-900">{totalTeams}</div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                      <span className="text-slate-500 text-sm font-medium">Evaluated</span>
                      <CheckCircle2 className="text-emerald-500" size={20} />
                  </div>
                  <div className="text-3xl font-bold text-slate-900">{evaluatedCount}</div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                      <span className="text-slate-500 text-sm font-medium">Shortlisted</span>
                      <Award className="text-pink-500" size={20} />
                  </div>
                  <div className="text-3xl font-bold text-slate-900">{shortlistedCount}</div>
              </div>
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-start mb-2">
                      <span className="text-slate-500 text-sm font-medium">Avg Score</span>
                      <TrendingUp className="text-indigo-500" size={20} />
                  </div>
                  <div className="text-3xl font-bold text-slate-900">7.8</div>
              </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Performance Chart */}
              <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
                      <TrendingUp size={18} className="text-slate-400" /> Aggregate Scores
                  </h3>
                  <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={chartData}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="name" axisLine={false} tickLine={false} />
                              <YAxis hide domain={[0, 10]} />
                              <Tooltip />
                              <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                                  {chartData.map((entry, index) => (
                                      <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                              </Bar>
                          </BarChart>
                      </ResponsiveContainer>
                  </div>
              </div>

              {/* Insights */}
              <div className="bg-gradient-to-br from-indigo-900 to-slate-900 p-6 rounded-xl shadow-lg text-white">
                  <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                      <BrainCircuit className="text-indigo-400" /> AI Strategic Insights
                  </h3>
                  <div className="space-y-4">
                      <div className="bg-white/10 p-3 rounded border border-white/10 text-sm">
                          <strong>Trend:</strong> Technical depth scores are lower than average (6.9), indicating teams focused more on business pitches.
                      </div>
                      <div className="bg-white/10 p-3 rounded border border-white/10 text-sm">
                          <strong>Observation:</strong> Teams providing video demos had a 40% higher shortlist rate.
                      </div>
                      <div className="bg-white/10 p-3 rounded border border-white/10 text-sm">
                          <strong>Gap:</strong> 3 out of 5 teams missed detailing their monetization strategy.
                      </div>
                  </div>
              </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-200 bg-slate-50">
                  <h3 className="font-bold text-slate-700">Team Directory</h3>
              </div>
              <table className="w-full text-sm text-left">
                  <thead className="bg-white text-slate-500 border-b border-slate-200">
                      <tr>
                          <th className="px-6 py-3 font-medium">Team Name</th>
                          <th className="px-6 py-3 font-medium">Project</th>
                          <th className="px-6 py-3 font-medium">Status</th>
                          <th className="px-6 py-3 font-medium text-right">Date</th>
                      </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                      {MOCK_TEAMS.map((team) => (
                          <tr key={team.id} className="hover:bg-slate-50">
                              <td className="px-6 py-3 font-bold text-slate-900">{team.name}</td>
                              <td className="px-6 py-3 text-slate-600">{team.projectTitle}</td>
                              <td className="px-6 py-3">
                                  <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${
                                      team.status === 'live' ? 'bg-red-100 text-red-700' : 
                                      team.status === 'reviewed' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                                  }`}>
                                      {team.status}
                                  </span>
                              </td>
                              <td className="px-6 py-3 text-right text-slate-500">
                                  {new Date(team.submittedAt).toLocaleDateString()}
                              </td>
                          </tr>
                      ))}
                  </tbody>
              </table>
          </div>

          <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-3">
              <AlertTriangle className="text-amber-600 shrink-0" size={20} />
              <div>
                  <h4 className="text-sm font-bold text-amber-800">Note to Judges</h4>
                  <p className="text-sm text-amber-700 mt-1">
                      Final scores should be submitted by 5:00 PM. Please ensure all manual overrides are logged.
                  </p>
              </div>
          </div>
      </div>
    </div>
  );
};

export default ReportsView;