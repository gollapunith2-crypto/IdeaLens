import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, UserCheck, ArrowRight, Bot, Key } from 'lucide-react';
import { MOCK_TEAMS } from '../constants';

const HomeView: React.FC = () => {
  const navigate = useNavigate();
  const [studentTeamId, setStudentTeamId] = useState(MOCK_TEAMS[0].id);

  const handleJudgeLogin = () => {
    navigate('/judge');
  };

  const handleStudentLogin = () => {
    if (studentTeamId) {
      navigate(`/student/${studentTeamId}`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center relative overflow-hidden font-sans">
      
      {/* Background Ambience */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
          <div className="absolute -top-[20%] -left-[10%] w-[50%] h-[50%] bg-brand-600/20 rounded-full blur-[120px]" />
          <div className="absolute top-[40%] -right-[10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 w-full max-w-5xl px-6">
        
        {/* Header */}
        <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 mb-4 bg-slate-800/50 p-3 rounded-2xl border border-slate-700/50 backdrop-blur-sm">
                <div className="w-10 h-10 bg-brand-500 rounded-xl flex items-center justify-center shadow-lg shadow-brand-500/20">
                    <Bot className="text-white w-6 h-6" />
                </div>
                <h1 className="text-3xl font-bold text-white tracking-tight">IdeaLens</h1>
            </div>
            <p className="text-slate-400 text-lg max-w-xl mx-auto">
                AI Copilot for Hackathon Judging. Ensuring fairness, scalability, and instant feedback.
            </p>
        </div>

        {/* Portal Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            
            {/* Judge Portal */}
            <div className="group bg-slate-800/50 hover:bg-slate-800 border border-slate-700 hover:border-brand-500/50 p-8 rounded-3xl transition-all duration-300 flex flex-col relative overflow-hidden">
                <div className="absolute top-0 right-0 p-32 bg-brand-500/5 rounded-full blur-3xl -mr-16 -mt-16 transition-all group-hover:bg-brand-500/10" />
                
                <div className="w-14 h-14 bg-slate-900 rounded-2xl border border-slate-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="text-brand-400 w-7 h-7" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-2">Judge & Admin Portal</h2>
                <p className="text-slate-400 mb-8 flex-1">
                    Access evaluation dashboards, review submissions, and manage hackathon logistics.
                </p>

                <button 
                    onClick={handleJudgeLogin}
                    className="w-full py-4 bg-brand-600 hover:bg-brand-500 text-white rounded-xl font-semibold flex items-center justify-center gap-2 transition-all shadow-lg shadow-brand-900/20 group-hover:shadow-brand-500/20"
                >
                    Enter Dashboard <ArrowRight size={18} />
                </button>
            </div>

            {/* Student Portal */}
            <div className="group bg-slate-800/50 hover:bg-slate-800 border border-slate-700 hover:border-emerald-500/50 p-8 rounded-3xl transition-all duration-300 flex flex-col relative overflow-hidden">
                <div className="absolute top-0 right-0 p-32 bg-emerald-500/5 rounded-full blur-3xl -mr-16 -mt-16 transition-all group-hover:bg-emerald-500/10" />
                
                <div className="w-14 h-14 bg-slate-900 rounded-2xl border border-slate-700 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <UserCheck className="text-emerald-400 w-7 h-7" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-2">Participant Portal</h2>
                <p className="text-slate-400 mb-6 flex-1">
                    Track your submission status, view AI feedback, and complete your Round 2 interview.
                </p>

                <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700 mb-4">
                    <label className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-2 block">Select Team (Demo)</label>
                    <div className="relative">
                        <select 
                            value={studentTeamId}
                            onChange={(e) => setStudentTeamId(e.target.value)}
                            className="w-full bg-slate-800 border border-slate-600 text-white text-sm rounded-lg p-2.5 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none appearance-none cursor-pointer"
                        >
                            {MOCK_TEAMS.map(team => (
                                <option key={team.id} value={team.id}>
                                    {team.name} - {team.projectTitle}
                                </option>
                            ))}
                        </select>
                        <div className="absolute right-3 top-3 pointer-events-none">
                            <Key size={14} className="text-slate-500" />
                        </div>
                    </div>
                </div>

                <button 
                    onClick={handleStudentLogin}
                    className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-900/20 group-hover:shadow-emerald-500/20"
                >
                    Go to My Team <ArrowRight size={18} />
                </button>
            </div>

        </div>

        <div className="text-center mt-12">
            <p className="text-slate-600 text-xs uppercase tracking-widest font-medium">Powered by Gemini 1.5 Pro</p>
        </div>
      </div>
    </div>
  );
};

export default HomeView;