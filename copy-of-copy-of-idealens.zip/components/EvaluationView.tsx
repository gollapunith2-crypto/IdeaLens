import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_TEAMS } from '../constants';
import { Team, AnalysisResult, EvaluationStage, AnalysisStatus } from '../types';
import { analyzeSubmission, generateQuestion } from '../services/gemini';
import ScoreVisualizer from './ScoreVisualizer';
import { 
  ArrowLeft, Upload, Bot, Play, Pause, FileText, MessageSquare, CheckCircle2,
  Loader2, Mic, Heart, Shield, Send, User, ThumbsUp, ThumbsDown,
  AlertTriangle, Lightbulb, Sparkles, Video, Lock, Trash2, Clock, Film,
  Maximize2, Minimize2, ZoomIn, ZoomOut, ChevronLeft, ChevronRight, Eye, Calendar
} from 'lucide-react';

const EvaluationView: React.FC<{ isDemoMode: boolean }> = ({ isDemoMode }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [team, setTeam] = useState<Team | undefined>(undefined);
  const [stage, setStage] = useState<EvaluationStage>(EvaluationStage.PPT);
  const [isShortlisted, setIsShortlisted] = useState(false);
  const [round1Passed, setRound1Passed] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // PPT Viewer State
  const [currentSlide, setCurrentSlide] = useState(1);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const TOTAL_SLIDES = 12; // Mock total slides

  // Analysis Inputs
  const [inputText, setInputText] = useState('');
  
  // Status & Result
  const [status, setStatus] = useState<AnalysisStatus>('IDLE');
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  // QA
  const [chatHistory, setChatHistory] = useState<{role: 'user' | 'model', text: string}[]>([]);
  const [answerInput, setAnswerInput] = useState('');
  const [isGeneratingQuestion, setIsGeneratingQuestion] = useState(false);

  useEffect(() => {
    const found = MOCK_TEAMS.find(t => t.id === id);
    if (found) {
      setTeam(found);
      setIsShortlisted(!!found.isShortlisted);
      setRound1Passed(found.status === 'reviewed' || found.status === 'live');
      setInputText(found.description);
    }
  }, [id]);

  useEffect(() => {
    setAnalysisResult(null);
    setStatus('IDLE');
    // Reset viewer states on stage change
    setCurrentSlide(1);
    setZoomLevel(1);
    setIsFullscreen(false);
  }, [stage]);

  const handleStageChange = (targetStage: EvaluationStage) => {
      if (targetStage !== EvaluationStage.PPT && !round1Passed) {
         setErrorMessage("Complete Round 1 first.");
         return;
      }
      setStage(targetStage);
  };

  const handleAnalyze = async () => {
    if (!inputText) {
        setErrorMessage("No submission context available.");
        return;
    }
    setAnalysisResult(null);
    setStatus('PREPARING_INPUT');
    
    const mode = stage === EvaluationStage.VIDEO ? 'VIDEO' : 'PPT';
    // Judge View: Pass null for fileInput as we rely on the text context + mock backend for demo
    const result = await analyzeSubmission(inputText, null, mode, isDemoMode, setStatus);
    
    setAnalysisResult(result);
    if (mode === 'PPT' && result.readiness_recommendation === 'PASS') {
        setRound1Passed(true);
    }
  };

  const handleGenerateQuestion = async () => {
    setIsGeneratingQuestion(true);
    const q = await generateQuestion(team?.description || "", chatHistory, isDemoMode);
    setChatHistory(prev => [...prev, { role: 'model', text: q }]);
    setIsGeneratingQuestion(false);
  };

  const handleSendAnswer = () => {
      if (!answerInput.trim()) return;
      setChatHistory(prev => [...prev, { role: 'user', text: answerInput }]);
      setAnswerInput('');
  };

  // PPT Viewer Controls
  const handleNextSlide = () => setCurrentSlide(prev => Math.min(prev + 1, TOTAL_SLIDES));
  const handlePrevSlide = () => setCurrentSlide(prev => Math.max(prev - 1, 1));
  const handleZoomIn = () => setZoomLevel(prev => Math.min(prev + 0.25, 2.0));
  const handleZoomOut = () => setZoomLevel(prev => Math.max(prev - 0.25, 0.5));
  const toggleFullscreen = () => setIsFullscreen(!isFullscreen);

  // Mock Slide Content based on index
  const getSlideContent = (index: number) => {
      const contents = [
          { title: team?.projectTitle, subtitle: "Investor Pitch Deck" },
          { title: "Problem Statement", subtitle: "Current inefficiencies in the market" },
          { title: "Our Solution", subtitle: "AI-driven approach to solve the core issue" },
          { title: "Market Size", subtitle: "TAM, SAM, SOM Analysis" },
          { title: "Business Model", subtitle: "Revenue streams and pricing strategy" },
          { title: "Competition", subtitle: "Competitive landscape and advantage" },
          { title: "Go-to-Market", subtitle: "Acquisition channels and growth strategy" },
          { title: "Product Roadmap", subtitle: "Q1 - Q4 Development Plan" },
          { title: "Financial Projections", subtitle: "3-Year P&L Forecast" },
          { title: "The Team", subtitle: "Founders and Advisors" },
          { title: "Ask", subtitle: "Funding requirements and allocation" },
          { title: "Thank You", subtitle: "Contact information and Q&A" },
      ];
      return contents[index - 1] || contents[0];
  };

  const isVideoMode = stage === EvaluationStage.VIDEO;
  const isAnalyzing = status !== 'IDLE' && status !== 'READY' && status !== 'BLOCKED' && status !== 'ERROR';

  if (!team) return <div>Loading...</div>;

  return (
    <div className="flex flex-col h-screen bg-slate-50 relative overflow-hidden font-sans">
      {/* Error Toast */}
      {errorMessage && (
        <div 
          onClick={() => setErrorMessage(null)}
          className="fixed top-20 right-6 bg-rose-600 text-white px-5 py-4 rounded-xl shadow-2xl z-50 flex items-center gap-3 cursor-pointer"
        >
            <AlertTriangle size={20} />
            <div>
                <h4 className="font-bold text-sm">Error</h4>
                <p className="text-xs">{errorMessage}</p>
            </div>
        </div>
      )}

      {/* Header */}
      <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6 z-10 relative">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/judge')} className="p-2 hover:bg-slate-100 rounded-full text-slate-500">
            <ArrowLeft size={20} />
          </button>
          <div>
            <h1 className="font-bold text-slate-900 leading-tight">{team.projectTitle}</h1>
            <p className="text-xs text-slate-500 flex items-center gap-1">
                <User size={10} /> {team.name}
            </p>
          </div>
        </div>
        
        <div className="flex items-center bg-slate-100 p-1 rounded-lg">
           <button onClick={() => handleStageChange(EvaluationStage.PPT)} className={`px-3 py-1.5 rounded text-xs font-bold transition-all ${stage === EvaluationStage.PPT ? 'bg-white shadow text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>
               1. PPT Review
           </button>
           <button onClick={() => handleStageChange(EvaluationStage.VIDEO)} className={`px-3 py-1.5 rounded text-xs font-bold transition-all ${stage === EvaluationStage.VIDEO ? 'bg-white shadow text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>
               2. Video Demo
           </button>
           <button onClick={() => handleStageChange(EvaluationStage.LIVE_QA)} className={`px-3 py-1.5 rounded text-xs font-bold transition-all ${stage === EvaluationStage.LIVE_QA ? 'bg-white shadow text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>
               3. Live Q&A
           </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        
        {/* Left Panel: Read-Only Submission Viewer */}
        <div className="w-1/2 p-6 overflow-y-auto border-r border-slate-200 bg-white flex flex-col">
          {stage !== EvaluationStage.LIVE_QA ? (
            <div className="space-y-6 flex flex-col h-full">
                
                {/* Header Info */}
                <div className="flex items-center justify-between">
                    <div>
                        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                           {isVideoMode ? <Film size={20} className="text-indigo-600" /> : <FileText size={20} className="text-indigo-600" />}
                           {isVideoMode ? "Submitted Demo Video" : "Submitted Pitch Deck"}
                        </h2>
                        <p className="text-xs text-slate-500 flex items-center gap-2 mt-1">
                            <Clock size={12} /> Uploaded on {new Date(team.submittedAt).toLocaleDateString()}
                            <span className="text-slate-300">|</span>
                            <span className="bg-slate-100 px-1.5 py-0.5 rounded text-[10px] font-medium text-slate-600 uppercase tracking-wide">Read-Only</span>
                        </p>
                    </div>
                </div>

                {/* Document/Video Viewer */}
                <div className={`bg-slate-100 rounded-xl border border-slate-200 overflow-hidden flex flex-col shadow-inner relative group transition-all duration-300 ${isFullscreen ? 'fixed inset-0 z-50 rounded-none m-0' : 'flex-1'}`}>
                    
                    {/* Viewer Toolbar */}
                    <div className="bg-white border-b border-slate-200 p-2 flex items-center justify-between z-10 shrink-0">
                         <div className="flex items-center gap-2">
                             {!isVideoMode && (
                                <div className="flex items-center bg-slate-100 rounded-lg p-1">
                                    <button 
                                        onClick={handlePrevSlide} 
                                        disabled={currentSlide === 1}
                                        className="p-1 hover:bg-white rounded shadow-sm text-slate-500 disabled:opacity-30 disabled:hover:bg-transparent"
                                    >
                                        <ChevronLeft size={14} />
                                    </button>
                                    <span className="text-xs font-mono w-16 text-center text-slate-600 font-bold select-none">
                                        {currentSlide} / {TOTAL_SLIDES}
                                    </span>
                                    <button 
                                        onClick={handleNextSlide}
                                        disabled={currentSlide === TOTAL_SLIDES}
                                        className="p-1 hover:bg-white rounded shadow-sm text-slate-500 disabled:opacity-30 disabled:hover:bg-transparent"
                                    >
                                        <ChevronRight size={14} />
                                    </button>
                                </div>
                             )}
                         </div>
                         <div className="flex items-center gap-2">
                             {!isVideoMode && (
                                 <>
                                    <button onClick={handleZoomOut} disabled={zoomLevel <= 0.5} className="p-1.5 text-slate-400 hover:text-slate-600 disabled:opacity-30"><ZoomOut size={16} /></button>
                                    <span className="text-[10px] w-8 text-center text-slate-400">{Math.round(zoomLevel * 100)}%</span>
                                    <button onClick={handleZoomIn} disabled={zoomLevel >= 2.0} className="p-1.5 text-slate-400 hover:text-slate-600 disabled:opacity-30"><ZoomIn size={16} /></button>
                                    <div className="w-px h-4 bg-slate-200 mx-1" />
                                 </>
                             )}
                             <button 
                                onClick={toggleFullscreen} 
                                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded transition-colors"
                                title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                             >
                                {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                             </button>
                         </div>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 overflow-auto bg-slate-900 relative flex items-center justify-center">
                        {isVideoMode ? (
                             // Original Video Binding (Restored)
                             team.videoUrl ? (
                                <video 
                                    controls
                                    src={team.videoUrl}
                                    className="w-full h-full object-contain bg-black"
                                >
                                    Your browser does not support the video tag.
                                </video>
                             ) : (
                                <div className="flex flex-col items-center justify-center text-slate-500">
                                    <Film size={48} className="mb-4 opacity-50" />
                                    <p className="font-bold text-sm">No Demo Video Uploaded</p>
                                    <p className="text-xs">The team has not submitted a video for Round 2.</p>
                                </div>
                             )
                        ) : (
                             // PPT Slide Placeholder
                             <div 
                                className="aspect-[4/3] w-full max-w-md bg-white shadow-2xl rounded flex flex-col overflow-hidden transition-all duration-300 origin-center"
                                style={{ transform: `scale(${zoomLevel})` }}
                             >
                                 {/* Slide Header */}
                                 <div className="h-3 bg-brand-600 w-full" />
                                 <div className="flex-1 p-8 flex flex-col select-none">
                                     <h1 className="text-2xl font-bold text-slate-800 mb-2">{getSlideContent(currentSlide).title}</h1>
                                     <h2 className="text-lg text-slate-500 mb-8 font-light">{getSlideContent(currentSlide).subtitle}</h2>
                                     
                                     <div className="space-y-4 mt-auto opacity-50">
                                         <div className="h-2 bg-slate-200 rounded w-3/4" />
                                         <div className="h-2 bg-slate-200 rounded w-full" />
                                         <div className="h-2 bg-slate-200 rounded w-5/6" />
                                         <div className="h-2 bg-slate-200 rounded w-1/2" />
                                     </div>

                                     <div className="mt-8 flex gap-4 opacity-50">
                                         <div className="w-1/2 h-24 bg-slate-50 rounded border border-slate-100" />
                                         <div className="w-1/2 h-24 bg-slate-50 rounded border border-slate-100" />
                                     </div>
                                 </div>
                                 {/* Slide Footer */}
                                 <div className="h-8 bg-slate-50 border-t border-slate-100 flex items-center justify-between px-4">
                                     <span className="text-[10px] text-slate-400">Confidential - For Review Only</span>
                                     <span className="text-[10px] text-slate-400">Slide {currentSlide}</span>
                                 </div>
                             </div>
                        )}
                    </div>
                </div>

                {/* Context Text (Read Only) */}
                {!isFullscreen && (
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                        <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Project Context</h3>
                        <p className="text-sm text-slate-700 leading-relaxed max-h-32 overflow-y-auto">
                            {team.description}
                        </p>
                    </div>
                )}

                {/* Analysis Action */}
                {!isFullscreen && (
                    <div className="mt-auto pt-2">
                        {round1Passed && stage === EvaluationStage.PPT ? (
                            <div className="w-full bg-emerald-50 border border-emerald-100 text-emerald-700 py-3 rounded-xl font-bold flex items-center justify-center gap-2">
                                <CheckCircle2 size={18} /> PPT Analyzed & Verified
                            </div>
                        ) : (
                            <button 
                                onClick={handleAnalyze}
                                disabled={isAnalyzing}
                                className={`w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 text-white shadow-lg transition-all ${
                                    isAnalyzing 
                                    ? 'bg-slate-400 cursor-not-allowed' 
                                    : 'bg-brand-600 hover:bg-brand-700 hover:shadow-brand-900/20 active:scale-[0.98]'
                                }`}
                            >
                                {isAnalyzing ? (
                                    <><Loader2 className="animate-spin" size={18} /> analyzing content...</>
                                ) : (
                                    <><Bot size={18} /> {isVideoMode ? 'Analyze Video Content' : 'Analyze Pitch Deck'}</>
                                )}
                            </button>
                        )}
                    </div>
                )}

            </div>
          ) : (
            // LIVE QA LEFT PANEL
            <div className="h-full flex flex-col items-center justify-center bg-slate-900 rounded-2xl text-white p-8 text-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/50 to-slate-900/50 z-0" />
                <div className="relative z-10">
                    <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-700 shadow-xl">
                        <Mic className="w-10 h-10 text-brand-400" />
                    </div>
                    <h3 className="text-2xl font-bold mb-2">Live Interview Active</h3>
                    <p className="text-slate-400 max-w-xs mx-auto mb-8">
                        The candidate is currently in the session. Use the panel on the right to generate questions and log answers.
                    </p>
                    <div className="flex items-center justify-center gap-2 text-xs font-mono text-emerald-400 bg-emerald-950/30 px-3 py-1.5 rounded-full border border-emerald-900/50 animate-pulse">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        SESSION CONNECTED
                    </div>
                </div>
            </div>
          )}
        </div>

        {/* Right Panel: AI Results & Tools */}
        <div className="w-1/2 bg-slate-50 flex flex-col overflow-hidden">
            {stage !== EvaluationStage.LIVE_QA ? (
                <div className="flex-1 overflow-y-auto p-6 relative">
                    {isAnalyzing && (
                        <div className="absolute inset-0 bg-white/80 z-20 flex flex-col items-center justify-center backdrop-blur-sm transition-all duration-300">
                            <Loader2 size={48} className="animate-spin text-brand-500 mb-4" />
                            <p className="font-bold text-slate-700 text-lg animate-pulse">{status === 'IDLE' ? 'Initializing...' : status.replace('_', ' ')}</p>
                            <p className="text-sm text-slate-500 mt-2">AI is processing the submission...</p>
                        </div>
                    )}
                    
                    {!analysisResult && !isAnalyzing && (
                        <div className="h-full flex flex-col items-center justify-center text-center text-slate-400">
                            <Bot size={64} className="mb-4 opacity-20" />
                            <p className="text-lg font-medium">Ready to Analyze</p>
                            <p className="text-sm">Click the button to run the evaluation model.</p>
                        </div>
                    )}

                    {analysisResult && (
                        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            {stage === EvaluationStage.PPT && (
                                <>
                                    <div className={`p-5 rounded-xl border-l-4 shadow-sm ${analysisResult.readiness_recommendation === 'PASS' ? 'bg-white border-emerald-500' : 'bg-white border-amber-500'}`}>
                                        <div className="flex items-center justify-between mb-2">
                                            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Recommendation</span>
                                            {analysisResult.readiness_recommendation === 'PASS' ? (
                                                <span className="bg-emerald-100 text-emerald-700 px-2 py-1 rounded text-xs font-bold flex items-center gap-1"><CheckCircle2 size={12}/> PASS TO ROUND 2</span>
                                            ) : (
                                                <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs font-bold flex items-center gap-1"><AlertTriangle size={12}/> HOLD FOR REVIEW</span>
                                            )}
                                        </div>
                                        <h3 className="font-bold text-lg text-slate-800 mb-1">{analysisResult.readiness_recommendation}</h3>
                                        <p className="text-sm text-slate-600 leading-relaxed">{analysisResult.reason_for_recommendation}</p>
                                    </div>
                                    <ScoreVisualizer data={analysisResult} />
                                    
                                    <div className="grid grid-cols-2 gap-4">
                                        <div className="bg-white p-4 rounded-xl border border-slate-200">
                                            <h4 className="font-bold text-sm text-slate-700 mb-3">Key Strengths</h4>
                                            <ul className="space-y-2">
                                                {analysisResult.key_strengths?.map((s, i) => (
                                                    <li key={i} className="text-xs text-slate-600 flex items-start gap-2">
                                                        <span className="text-emerald-500 mt-0.5">•</span> {s}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                        <div className="bg-white p-4 rounded-xl border border-slate-200">
                                            <h4 className="font-bold text-sm text-slate-700 mb-3">Issues</h4>
                                            <ul className="space-y-2">
                                                {analysisResult.blocking_issues?.length ? analysisResult.blocking_issues.map((s, i) => (
                                                    <li key={i} className="text-xs text-slate-600 flex items-start gap-2">
                                                        <span className="text-rose-500 mt-0.5">•</span> {s}
                                                    </li>
                                                )) : <li className="text-xs text-slate-400 italic">No major issues detected.</li>}
                                            </ul>
                                        </div>
                                    </div>
                                </>
                            )}
                            
                            {stage === EvaluationStage.VIDEO && (
                                <div className="space-y-4">
                                    <div className="bg-white p-6 rounded-xl border border-brand-100 shadow-sm relative overflow-hidden">
                                        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-50 rounded-full -mr-16 -mt-16 z-0" />
                                        <h4 className="font-bold text-brand-700 text-xs uppercase mb-3 relative z-10 flex items-center gap-2">
                                            <Sparkles size={14} /> AI First Impression
                                        </h4>
                                        <p className="text-lg text-slate-800 font-medium relative z-10 leading-relaxed">
                                            "{analysisResult.first_impression}"
                                        </p>
                                    </div>
                                    {analysisResult.first_question && (
                                        <div className="bg-slate-900 text-white p-6 rounded-xl shadow-lg relative overflow-hidden group">
                                            <div className="absolute right-0 top-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
                                                <Bot size={80} />
                                            </div>
                                            <h4 className="font-bold text-brand-300 text-xs uppercase mb-3">Suggested Follow-up Question</h4>
                                            <p className="text-xl font-light leading-relaxed">"{analysisResult.first_question.question_text}"</p>
                                            <div className="mt-4 pt-4 border-t border-white/10 flex items-center gap-2">
                                                <span className="text-[10px] font-bold bg-white/20 px-2 py-1 rounded uppercase tracking-wider">Intent</span>
                                                <span className="text-xs text-slate-300">{analysisResult.first_question.intent}</span>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                </div>
            ) : (
                <div className="flex flex-col h-full bg-white border-l border-slate-200">
                    <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                        <h3 className="font-bold text-slate-700 flex items-center gap-2">
                            <Bot className="text-indigo-600" size={18} /> Interview Assistant
                        </h3>
                        <span className="text-[10px] bg-slate-200 px-2 py-1 rounded text-slate-600 font-bold">LIVE MODE</span>
                    </div>
                    
                    <div className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50/50">
                        {chatHistory.length === 0 && (
                            <div className="text-center text-slate-400 mt-10">
                                <MessageSquare size={32} className="mx-auto mb-2 opacity-20" />
                                <p className="text-sm">Generate questions to start the log.</p>
                            </div>
                        )}
                        {chatHistory.map((msg, i) => (
                            <div key={i} className={`p-4 rounded-xl text-sm leading-relaxed shadow-sm max-w-[90%] ${msg.role === 'model' ? 'bg-white text-slate-700 mr-auto border border-slate-200' : 'bg-indigo-600 text-white ml-auto'}`}>
                                <div className="text-[10px] font-bold opacity-50 mb-1 uppercase">{msg.role === 'model' ? 'Suggested Question' : 'Notes'}</div>
                                {msg.text}
                            </div>
                        ))}
                    </div>
                    
                    <div className="p-4 bg-white border-t border-slate-200 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
                        <button 
                            onClick={handleGenerateQuestion} 
                            disabled={isGeneratingQuestion} 
                            className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3.5 rounded-xl font-bold mb-4 disabled:opacity-50 transition-all shadow-lg flex items-center justify-center gap-2"
                        >
                            {isGeneratingQuestion ? <Loader2 className="animate-spin" size={18} /> : <Lightbulb size={18} className="text-yellow-400" />}
                            Generate AI Question
                        </button>
                        <div className="relative">
                            <input 
                                className="w-full border border-slate-200 rounded-xl pl-4 pr-12 py-3 focus:ring-2 focus:ring-indigo-500 outline-none text-sm bg-slate-50"
                                value={answerInput}
                                onChange={(e) => setAnswerInput(e.target.value)}
                                placeholder="Log candidate answer or notes..."
                                onKeyDown={(e) => e.key === 'Enter' && handleSendAnswer()}
                            />
                            <button 
                                onClick={handleSendAnswer}
                                disabled={!answerInput.trim()}
                                className="absolute right-2 top-2 p-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:bg-slate-300"
                            >
                                <Send size={16} />
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default EvaluationView;