import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Users, FileText, Settings, ShieldCheck, ArrowLeft, ExternalLink } from 'lucide-react';
import { MOCK_TEAMS } from '../constants';

const Sidebar: React.FC = () => {
  const navigate = useNavigate();

  const handleSettingsClick = () => {
      // Simple configuration for Hackathon context to allow judges to bring their own key
      // if the environment variable isn't set.
      const currentKey = localStorage.getItem('gemini_api_key') || '';
      const newKey = window.prompt("Judge Configuration: Enter Gemini API Key (Optional)", currentKey);
      
      if (newKey !== null) { // User clicked OK
          if (newKey.trim() === '') {
              localStorage.removeItem('gemini_api_key');
              alert("API Key removed from local storage.");
          } else {
              localStorage.setItem('gemini_api_key', newKey.trim());
              alert("API Key saved locally. Live mode is now enabled.");
              // Force reload to pick up the new key in the singleton
              window.location.reload();
          }
      }
  };

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col h-screen fixed left-0 top-0 z-50">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
          <div className="w-8 h-8 bg-brand-500 rounded-lg flex items-center justify-center">
            <ShieldCheck className="text-white w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">IdeaLens</h1>
        </div>
        <p className="text-xs text-slate-500 mt-2">AI Copilot for Judges</p>
      </div>

      <div className="px-4 pt-4">
        <button 
            onClick={() => navigate('/')} 
            className="flex items-center gap-2 w-full px-4 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all text-sm font-bold"
        >
            <ArrowLeft size={16} /> Back to Start
        </button>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <NavLink 
          to="/judge" 
          end
          className={({ isActive }) => 
            `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${isActive ? 'bg-brand-600 text-white' : 'hover:bg-slate-800'}`
          }
        >
          <LayoutDashboard size={20} />
          <span className="font-medium">Dashboard</span>
        </NavLink>
        
        <div className="px-4 py-2 mt-6 mb-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Review
        </div>
        
        <NavLink 
          to="/judge/teams" 
          className={({ isActive }) => 
            `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${isActive ? 'bg-brand-600 text-white' : 'hover:bg-slate-800'}`
          }
        >
            <Users size={20} />
            <span className="font-medium">Teams</span>
        </NavLink>
        
        <NavLink 
          to="/judge/reports" 
          className={({ isActive }) => 
            `flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${isActive ? 'bg-brand-600 text-white' : 'hover:bg-slate-800'}`
          }
        >
            <FileText size={20} />
            <span className="font-medium">Reports</span>
        </NavLink>

        {/* Demo Links for Participant Views */}
        <div className="px-4 py-2 mt-6 mb-2 text-xs font-semibold text-slate-500 uppercase tracking-wider">
          Participant Views (Demo)
        </div>
        <div className="space-y-1">
            {MOCK_TEAMS.slice(0, 3).map(team => (
                <NavLink 
                    key={team.id}
                    to={`/student/${team.id}`}
                    target="_blank"
                    className={({ isActive }) => 
                        `flex items-center gap-2 px-4 py-2 text-xs rounded-lg transition-colors ${isActive ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`
                    }
                >
                    <ExternalLink size={12} />
                    <span className="truncate">{team.name}</span>
                </NavLink>
            ))}
        </div>

      </nav>

      <div className="p-4 border-t border-slate-800 space-y-2">
        <button 
          onClick={handleSettingsClick}
          className="flex items-center gap-3 px-4 py-2 text-slate-400 hover:text-white transition-colors w-full text-left"
        >
          <Settings size={20} />
          <span>Settings</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;