import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { MOCK_TEAMS } from '../constants';
import { Team, AnalysisResult, EvaluationStage, AnalysisStatus } from '../types';
import { analyzeSubmission, generateInterviewQuestion, generateLiveSessionScores } from '../services/gemini';
import ScoreVisualizer from './ScoreVisualizer';
import { jsPDF } from 'jspdf';
import { 
  ArrowLeft, Upload, Bot, Play, FileText, CheckCircle2,
  Loader2, Mic, Heart, Send, AlertTriangle, Lightbulb, 
  Video, Lock, Award, Film, MicOff, Keyboard, StopCircle, Volume2, CameraOff, ArrowRight, Download
} from 'lucide-react';

const TeamPortalView: React.FC<{ isDemoMode: boolean }> = ({ isDemoMode }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [team, setTeam] = useState<Team | undefined>(undefined);
  
  // Stages & Gating
  const [stage, setStage] = useState<EvaluationStage>(EvaluationStage.PPT);
  const [round1Passed, setRound1Passed] = useState(false);
  const [round2Passed, setRound2Passed] = useState(false);

  // Analysis Inputs
  const [inputText, setInputText] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  // Status & Result
  const [status, setStatus] = useState<AnalysisStatus>('IDLE');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);

  // Q&A / Chat State
  const [chatHistory, setChatHistory] = useState<{role: 'ai' | 'user', text: string}[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isChatProcessing, setIsChatProcessing] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Voice Input & Output State
  const [isListening, setIsListening] = useState(false);
  const [isAiSpeaking, setIsAiSpeaking] = useState(false);
  const [isVoiceSupported, setIsVoiceSupported] = useState(false);
  const [inputMode, setInputMode] = useState<'VOICE' | 'TEXT'>('VOICE');
  const recognitionRef = useRef<any>(null);

  // Camera State
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraPermissionDenied, setCameraPermissionDenied] = useState(false);

  // Session Management
  const [isEndingSession, setIsEndingSession] = useState(false);
  const [liveSessionFinished, setLiveSessionFinished] = useState(false);

  // Certificate State
  const [certificateUnlocked, setCertificateUnlocked] = useState(false);

  useEffect(() => {
    const found = MOCK_TEAMS.find(t => t.id === id);
    if (found) {
      setTeam(found);
      // Pre-fill text for demo convenience
      setInputText(found.description);
      
      // Restore state based on mock status (for demo purposes)
      if (found.status === 'reviewed' || found.status === 'live') {
          setRound1Passed(true);
      }

      // Check for certificate persistence
      const isCertUnlocked = localStorage.getItem(`cert_unlocked_${found.id}`) === 'true';
      if (isCertUnlocked) {
          setCertificateUnlocked(true);
          // If certificate is unlocked, implied session finished logic for UI restoration could be added here
          // For now, we keep certificate separate from live session state restoration to avoid complexity
      }
    }
  }, [id]);

  useEffect(() => {
    // Reset local result view when switching stages
    setAnalysisResult(null);
    setStatus('IDLE');
    setSelectedFile(null);
    // Cancel any ongoing speech when switching stages
    window.speechSynthesis.cancel();
    setIsAiSpeaking(false);
  }, [stage]);

  // Clean up speech on unmount
  useEffect(() => {
      return () => {
          window.speechSynthesis.cancel();
      };
  }, []);

  // Camera Management
  const stopCamera = () => {
      if (streamRef.current) {
          streamRef.current.getTracks().forEach(track => track.stop());
          streamRef.current = null;
          setCameraStream(null);
      }
  };

  useEffect(() => {
      if (stage === EvaluationStage.LIVE_QA && !liveSessionFinished) {
          navigator.mediaDevices.getUserMedia({ video: true, audio: true })
            .then(stream => {
                streamRef.current = stream;
                setCameraStream(stream);
                setCameraPermissionDenied(false);
            })
            .catch(err => {
                console.error("Camera access denied:", err);
                setCameraPermissionDenied(true);
            });
      } else {
          stopCamera();
      }
      return () => stopCamera();
  }, [stage, liveSessionFinished]);

  // Attach stream to video element
  useEffect(() => {
      if (videoRef.current && cameraStream) {
          videoRef.current.srcObject = cameraStream;
      }
  }, [cameraStream]);

  // Initialize Speech Recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        setIsVoiceSupported(true);
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        // Set continuous to false for "Walkie Talkie" style (Speak -> Process -> Reply)
        recognition.continuous = false; 
        recognition.interimResults = true;
        recognition.lang = 'en-US';

        recognition.onresult = (event: any) => {
            let finalTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    finalTranscript += event.results[i][0].transcript;
                }
            }
            if (finalTranscript) {
                setChatInput(finalTranscript);
                // AUTO SUBMIT when speech is final
                handleSendChat(finalTranscript);
            }
        };

        recognition.onerror = (event: any) => {
            console.error('Speech recognition error', event.error);
            setIsListening(false);
            if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
                setInputMode('TEXT');
                setErrorMessage("Microphone access denied. Switched to text mode.");
            }
        };

        recognition.onend = () => {
            setIsListening(false);
        };

        recognitionRef.current = recognition;
    } else {
        setIsVoiceSupported(false);
        setInputMode('TEXT');
    }
  }, []);

  // Scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, isChatProcessing]);

  // --- Handlers ---

  const handleBackToStart = () => {
      if (stage === EvaluationStage.LIVE_QA && !liveSessionFinished) {
          if (window.confirm("Leaving this page will end the current session. Continue?")) {
              navigate('/');
          }
      } else {
          navigate('/');
      }
  };

  const handleStageChange = (targetStage: EvaluationStage) => {
      if (targetStage === EvaluationStage.VIDEO && !round1Passed) {
         setErrorMessage("Please complete Round 1 (PPT Review) successfully first.");
         return;
      }
      if (targetStage === EvaluationStage.LIVE_QA && !round2Passed) {
          setErrorMessage("Please complete Round 2 (Video Analysis) first.");
          return;
      }
      setStage(targetStage);
      setErrorMessage(null);
  };

  const handleAnalyze = async () => {
    if (!inputText && !selectedFile) {
        setErrorMessage("Please provide text or upload a file.");
        return;
    }
    setAnalysisResult(null);
    setStatus('PREPARING_INPUT');
    setErrorMessage(null);
    
    const mode = stage === EvaluationStage.VIDEO ? 'VIDEO' : 'PPT';
    const result = await analyzeSubmission(inputText, selectedFile, mode, isDemoMode, setStatus);
    
    setAnalysisResult(result);
    
    // Gating Logic
    if (mode === 'PPT' && result.readiness_recommendation === 'PASS') {
        setRound1Passed(true);
    }
    // For Video, we assume if analysis is successful (not BLOCKED), they pass to Q&A
    if (mode === 'VIDEO' && result.status !== 'BLOCKED') {
        setRound2Passed(true);
    }
  };

  // --- Voice & Chat Logic ---

  const speakResponse = (text: string) => {
      if ('speechSynthesis' in window) {
          // Stop any current speech
          window.speechSynthesis.cancel();
          
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.onstart = () => setIsAiSpeaking(true);
          utterance.onend = () => setIsAiSpeaking(false);
          utterance.onerror = () => setIsAiSpeaking(false);
          
          // Optional: Select a specific voice if available
          const voices = window.speechSynthesis.getVoices();
          const preferredVoice = voices.find(v => v.lang.includes('en') && v.name.includes('Google'));
          if (preferredVoice) utterance.voice = preferredVoice;

          window.speechSynthesis.speak(utterance);
      }
  };

  const handleStartChat = async () => {
      setIsChatProcessing(true);
      // Simulate connection delay
      await new Promise(r => setTimeout(r, 1000));
      
      const greeting = `Hello ${team?.name}. I've reviewed your materials. Let's begin the technical Q&A.`;
      setChatHistory([{ role: 'ai', text: greeting }]);
      setIsChatProcessing(false);
      
      // Auto-speak the greeting
      speakResponse(greeting);
  };

  const handleSendChat = async (manualInput?: string) => {
      // Use manual input (from voice) or state input (from text box)
      const userMsg = manualInput || chatInput;
      if (!userMsg?.trim()) return;
      
      // 1. Add User Message to History
      setChatHistory(prev => [...prev, { role: 'user', text: userMsg }]);
      setChatInput('');
      setIsChatProcessing(true);

      // Stop listening if sending
      if (isListening && recognitionRef.current) {
          recognitionRef.current.stop();
          setIsListening(false);
      }

      // 2. Generate AI Response
      // Pass the updated history including the message just added (we reconstruct it here to avoid async state issues)
      const cleanHistory = [...chatHistory, { role: 'user' as const, text: userMsg }];

      const response = await generateInterviewQuestion(cleanHistory, team?.description || '');
      
      // 3. Add AI Message to History
      setChatHistory(prev => [...prev, { role: 'ai', text: response }]);
      setIsChatProcessing(false);

      // 4. Speak AI Response
      speakResponse(response);
  };

  const toggleListening = () => {
      if (!recognitionRef.current) return;
      
      if (isListening) {
          recognitionRef.current.stop();
          setIsListening(false);
      } else {
          // If AI is speaking, stop it so user can talk
          if (isAiSpeaking) {
              window.speechSynthesis.cancel();
              setIsAiSpeaking(false);
          }
          recognitionRef.current.start();
          setIsListening(true);
      }
  };

  const toggleInputMode = () => {
      if (inputMode === 'VOICE') {
          if (isListening) toggleListening();
          setInputMode('TEXT');
      } else {
          if (isVoiceSupported) {
              setInputMode('VOICE');
          } else {
              setErrorMessage("Voice input is not supported in this browser.");
          }
      }
  };

  const handleEndSession = async () => {
      if (isEndingSession) return;
      setIsEndingSession(true);

      // 1. Stop Inputs
      stopCamera();
      if (recognitionRef.current) recognitionRef.current.stop();
      window.speechSynthesis.cancel();
      setIsListening(false);
      setIsAiSpeaking(false);

      // 2. Generate Scores
      setStatus('PROCESSING_RESPONSE');
      try {
          const result = await generateLiveSessionScores(chatHistory, team?.description || '', isDemoMode);
          setAnalysisResult(result);
          setLiveSessionFinished(true);

          // 3. Unlock Certificate
          setCertificateUnlocked(true);
          if (team?.id) {
            localStorage.setItem(`cert_unlocked_${team.id}`, 'true');
          }

      } catch (e) {
          console.error(e);
          setErrorMessage("Failed to generate scores. Session saved.");
          setLiveSessionFinished(true); // Fail safe
      } finally {
          setIsEndingSession(false);
          setStatus('IDLE');
      }
  };

  const handleDownloadCertificate = () => {
      if (!team) return;
      
      const doc = new jsPDF({
          orientation: 'landscape',
          unit: 'mm',
          format: 'a4'
      });
      
      // Design: Professional Background
      doc.setFillColor(248, 250, 252); // slate-50
      doc.rect(0, 0, 297, 210, 'F');
      
      // Border
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(1);
      doc.rect(10, 10, 277, 190);
      
      // Inner Border (Brand)
      doc.setDrawColor(79, 70, 229); // Indigo-600
      doc.setLineWidth(1.5);
      doc.rect(12, 12, 273, 186);

      // Content
      doc.setTextColor(30, 41, 59);
      doc.setFontSize(32);
      doc.setFont("helvetica", "bold");
      doc.text("CERTIFICATE OF COMPLETION", 148.5, 55, { align: "center" });
      
      doc.setFontSize(16);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(100, 116, 139);
      doc.text("This certificate is awarded to", 148.5, 75, { align: "center" });
      
      doc.setFontSize(32);
      doc.setTextColor(79, 70, 229); // Indigo-600
      doc.setFont("helvetica", "bold");
      doc.text(team.name, 148.5, 95, { align: "center" });
      
      doc.setFontSize(14);
      doc.setTextColor(51, 65, 85);
      doc.setFont("helvetica", "normal");
      doc.text(`For successfully completing all evaluation rounds of the`, 148.5, 115, { align: "center" });
      doc.text(`IdeaLens AI Hackathon Assessment with the project:`, 148.5, 123, { align: "center" });
      
      doc.setFontSize(22);
      doc.setTextColor(15, 23, 42);
      doc.setFont("helvetica", "bold");
      doc.text(team.projectTitle, 148.5, 140, { align: "center" });

      // Footer
      const dateStr = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
      doc.setFontSize(12);
      doc.setTextColor(148, 163, 184);
      doc.setFont("helvetica", "normal");
      doc.text(`Completed on ${dateStr}`, 148.5, 170, { align: "center" });
      
      doc.setFontSize(10);
      doc.setTextColor(203, 213, 225);
      doc.text(`Certificate ID: IL-${team.id.toUpperCase()}-${Date.now().toString().slice(-6)}`, 148.5, 190, { align: "center" });

      doc.save(`Certificate-${team.name.replace(/\s+/g, '_')}.pdf`);
  };

  if (!team) return <div className="p-10 text-center">Loading...</div>;

  const isAnalyzing = status !== 'IDLE' && status !== 'READY' && status !== 'BLOCKED' && status !== 'ERROR';
  const isVideoMode = stage === EvaluationStage.VIDEO;

  return (
    <div className="flex flex-col h-screen bg-slate-50 relative overflow-hidden font-sans">
      
      {/* Error Toast */}
      {errorMessage && (
        <div 
          onClick={() => setErrorMessage(null)}
          className="fixed top-20 right-6 bg-rose-600 text-white px-5 py-4 rounded-xl shadow-2xl z-50 flex items-center gap-3 cursor-pointer animate-in slide-in-from-top-5 fade-in duration-300"
        >
            <AlertTriangle size={20} />
            <div>
                <h4 className="font-bold text-sm">Action Required</h4>
                <p className="text-xs">{errorMessage}</p>
            </div>
        </div>
      )}

      {/* Header */}
      <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-8 shrink-0">
        <div>
            <div className="flex items-center gap-4">
                <button onClick={handleBackToStart} className="flex items-center gap-2 hover:bg-slate-100 px-3 py-2 rounded-lg transition-colors text-slate-500 hover:text-slate-900">
                    <ArrowLeft size={20} />
                    <span className="font-bold text-sm">Back to Start</span>
                </button>
                <div className="h-8 w-px bg-slate-200 mx-2" />
                <div>
                    <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Project</span>
                    </div>
                    <h1 className="text-xl font-bold text-slate-900">{team.projectTitle}</h1>
                </div>
                <div className="h-8 w-px bg-slate-200 mx-2" />
                <div>
                    <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">Current Team</div>
                    <div className="font-medium text-slate-700">{team.name}</div>
                </div>
                <div className="h-8 w-px bg-slate-200 mx-2" />
                <div className="bg-slate-100 px-3 py-1 rounded-lg">
                    <div className="text-[10px] font-bold text-slate-500 uppercase">Round</div>
                    <div className="text-sm font-bold text-slate-900">
                        {stage === EvaluationStage.PPT ? '1 of 3' : stage === EvaluationStage.VIDEO ? '2 of 3' : '3 of 3'}
                    </div>
                </div>
            </div>
        </div>

        <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 text-slate-400 text-sm mr-4">
                 <span className={`w-2 h-2 rounded-full ${status === 'PROCESSING_RESPONSE' ? 'bg-amber-400 animate-pulse' : 'bg-slate-300'}`} />
                 {status === 'IDLE' ? 'Idle' : 'Processing...'}
             </div>
             {team.isShortlisted && (
                 <div className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg shadow-sm">
                     <Heart className="text-pink-500 fill-pink-500" size={16} />
                     <span className="font-bold text-slate-700 text-sm">Shortlist</span>
                 </div>
             )}
        </div>
      </header>

      {/* Progress Stepper */}
      <div className="bg-white border-b border-slate-200 px-8 py-6">
          <div className="flex items-center justify-center max-w-4xl mx-auto">
              {/* Step 1 */}
              <button 
                onClick={() => handleStageChange(EvaluationStage.PPT)}
                className={`flex flex-col items-center gap-2 w-40 relative group ${stage === EvaluationStage.PPT ? 'opacity-100' : 'opacity-60 hover:opacity-100'}`}
              >
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg transition-all ${round1Passed ? 'bg-emerald-500' : stage === EvaluationStage.PPT ? 'bg-indigo-600 scale-110 shadow-lg shadow-indigo-200' : 'bg-slate-200 text-slate-500'}`}>
                      {round1Passed ? <CheckCircle2 size={24} /> : '1'}
                  </div>
                  <div className="text-center">
                      <div className={`text-sm font-bold ${stage === EvaluationStage.PPT ? 'text-indigo-600' : 'text-slate-600'}`}>PPT Review</div>
                      <div className="text-[10px] text-slate-400 font-medium">Initial AI screening</div>
                  </div>
              </button>

              <div className={`h-0.5 w-24 mb-8 ${round1Passed ? 'bg-emerald-500' : 'bg-slate-200'}`} />

              {/* Step 2 */}
              <button 
                onClick={() => handleStageChange(EvaluationStage.VIDEO)}
                className={`flex flex-col items-center gap-2 w-40 relative group ${stage === EvaluationStage.VIDEO ? 'opacity-100' : 'opacity-60 hover:opacity-100'}`}
              >
                   <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg transition-all ${round2Passed ? 'bg-emerald-500' : stage === EvaluationStage.VIDEO ? 'bg-indigo-600 scale-110 shadow-lg shadow-indigo-200' : 'bg-slate-200 text-slate-500'}`}>
                       {round2Passed ? <CheckCircle2 size={24} /> : !round1Passed ? <Lock size={18} /> : '2'}
                  </div>
                  <div className="text-center">
                      <div className={`text-sm font-bold ${stage === EvaluationStage.VIDEO ? 'text-indigo-600' : 'text-slate-600'}`}>Video & Demo</div>
                      <div className="text-[10px] text-slate-400 font-medium">Analysis before interaction</div>
                  </div>
              </button>

              <div className={`h-0.5 w-24 mb-8 ${round2Passed ? 'bg-emerald-500' : 'bg-slate-200'}`} />

              {/* Step 3 */}
              <button 
                 onClick={() => handleStageChange(EvaluationStage.LIVE_QA)}
                 className={`flex flex-col items-center gap-2 w-40 relative group ${stage === EvaluationStage.LIVE_QA ? 'opacity-100' : 'opacity-60 hover:opacity-100'}`}
              >
                   <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg transition-all ${stage === EvaluationStage.LIVE_QA ? 'bg-indigo-600 scale-110 shadow-lg shadow-indigo-200' : 'bg-slate-200 text-slate-500'}`}>
                       {!round2Passed ? <Lock size={18} /> : <Mic size={20} />}
                  </div>
                  <div className="text-center">
                      <div className={`text-sm font-bold ${stage === EvaluationStage.LIVE_QA ? 'text-indigo-600' : 'text-slate-600'}`}>Live Q&A</div>
                      <div className="text-[10px] text-slate-400 font-medium">Judge depth & clarity</div>
                  </div>
              </button>
          </div>
      </div>

      {/* Main Content Area - Split View */}
      <div className="flex-1 flex overflow-hidden bg-slate-50">
          
          {/* LEFT PANEL: Inputs & Actions */}
          <div className="w-1/2 p-8 border-r border-slate-200 overflow-y-auto bg-white">
             {stage === EvaluationStage.LIVE_QA ? (
                 // Live Q&A Left Panel
                 <div className="h-full flex flex-col justify-center">
                    <div className="bg-slate-900 rounded-2xl aspect-video relative overflow-hidden flex items-center justify-center shadow-2xl">
                        
                        {liveSessionFinished ? (
                             // SESSION ENDED STATE
                             <div className="text-center z-20">
                                 <CheckCircle2 size={64} className="text-emerald-500 mx-auto mb-4" />
                                 <h3 className="text-2xl font-bold text-white mb-2">Interview Completed</h3>
                                 <p className="text-slate-400">Scores generated successfully.</p>
                             </div>
                        ) : (
                            // LIVE CAMERA STATE
                            <>
                                {cameraStream && (
                                    <video 
                                        ref={videoRef} 
                                        autoPlay 
                                        playsInline 
                                        muted 
                                        className="absolute inset-0 w-full h-full object-cover transform -scale-x-100 z-0"
                                    />
                                )}

                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />
                                
                                <div className="text-center z-20 pointer-events-none">
                                    {isAiSpeaking ? (
                                        <div className="flex flex-col items-center gap-4">
                                            <div className="flex gap-1 items-end h-8">
                                                <div className="w-1.5 bg-brand-400 animate-[bounce_1s_infinite] h-4"></div>
                                                <div className="w-1.5 bg-brand-400 animate-[bounce_1s_infinite_0.2s] h-8"></div>
                                                <div className="w-1.5 bg-brand-400 animate-[bounce_1s_infinite_0.4s] h-6"></div>
                                            </div>
                                            <span className="text-brand-300 font-mono text-sm shadow-black drop-shadow-md">AI Interviewer Speaking...</span>
                                        </div>
                                    ) : isChatProcessing ? (
                                        <div className="flex flex-col items-center gap-4">
                                            <Loader2 className="animate-spin text-brand-400" size={32} />
                                            <span className="text-brand-300 font-mono text-sm shadow-black drop-shadow-md">Generating Question...</span>
                                        </div>
                                    ) : (
                                        <div className="flex flex-col items-center gap-4">
                                            {!cameraStream && (
                                                cameraPermissionDenied ? (
                                                    <>
                                                        <CameraOff size={48} className="text-slate-500" />
                                                        <span className="text-slate-400 font-medium">Camera Access Denied</span>
                                                    </>
                                                ) : (
                                                    <>
                                                        <Video size={48} className="text-slate-500" />
                                                        <span className="text-slate-400 font-medium">Interview in Progress</span>
                                                    </>
                                                )
                                            )}
                                            
                                            {isListening && (
                                                <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-full backdrop-blur-md border border-slate-700">
                                                    <Mic size={14} className="text-emerald-400" />
                                                    <div className="flex gap-0.5">
                                                        <div className="w-1 h-3 bg-emerald-500 rounded-full animate-pulse" />
                                                        <div className="w-1 h-5 bg-emerald-500 rounded-full animate-pulse delay-75" />
                                                        <div className="w-1 h-2 bg-emerald-500 rounded-full animate-pulse delay-150" />
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>

                                {/* Overlays */}
                                <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
                                     <span className="bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded animate-pulse shadow-lg">● Live</span>
                                </div>
                            </>
                        )}
                    </div>
                    
                    <div className="mt-6">
                        <button 
                            className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg transition-all ${
                                liveSessionFinished 
                                ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-900/20'
                            }`}
                            onClick={handleEndSession}
                            disabled={liveSessionFinished || isEndingSession}
                        >
                            {isEndingSession ? (
                                <><Loader2 className="animate-spin" /> Finalizing...</>
                            ) : liveSessionFinished ? (
                                <><CheckCircle2 /> Session Closed</>
                            ) : (
                                <><Award size={18} /> End Session & Generate Scores</>
                            )}
                        </button>
                    </div>

                    <div className="mt-6 p-4 bg-slate-50 rounded-xl border border-slate-200">
                        <h4 className="text-xs font-bold text-slate-500 uppercase mb-2">Live Transcript</h4>
                        <div className="text-sm text-slate-600 h-32 overflow-y-auto italic font-mono space-y-2">
                             {chatHistory.length === 0 ? (
                                 <span className="opacity-50">Conversation will appear here...</span>
                             ) : (
                                 chatHistory.slice(-3).map((m, i) => (
                                     <p key={i}><span className="font-bold">{m.role === 'ai' ? 'Judge' : 'Team'}:</span> {m.text}</p>
                                 ))
                             )}
                        </div>
                    </div>
                 </div>
             ) : (
                 // PPT & Video Left Panel (Same as before)
                 <div className="space-y-6 max-w-xl mx-auto">
                    <div>
                        <h2 className="text-lg font-bold text-slate-900 mb-1">
                            {isVideoMode ? 'Upload Demo Video' : 'Upload Presentation'}
                        </h2>
                        <p className="text-slate-500 text-sm">
                            {isVideoMode ? 'Upload video explanation or paste transcript' : 'Upload PPT/PDF or paste pitch text for AI analysis'}
                        </p>
                    </div>

                    {/* File Drop Area */}
                    <div className="border-2 border-dashed border-slate-300 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors p-10 flex flex-col items-center justify-center text-center group cursor-pointer relative">
                        <input 
                            type="file" 
                            className="absolute inset-0 opacity-0 cursor-pointer" 
                            onChange={(e) => e.target.files?.[0] && setSelectedFile(e.target.files[0])}
                            disabled={isAnalyzing}
                            accept={isVideoMode ? "video/*" : "application/pdf"}
                        />
                        {selectedFile ? (
                            <div className="flex flex-col items-center animate-in fade-in zoom-in">
                                {isVideoMode ? <Film size={40} className="text-brand-600 mb-4" /> : <FileText size={40} className="text-brand-600 mb-4" />}
                                <span className="font-bold text-slate-700 text-lg mb-1">{selectedFile.name}</span>
                                <span className="text-slate-400 text-sm">{(selectedFile.size / (1024*1024)).toFixed(1)} MB</span>
                                <span className="mt-4 px-3 py-1 bg-brand-100 text-brand-700 text-xs font-bold rounded-full">
                                    {isVideoMode ? 'Video ready' : 'Ready for Analysis'}
                                </span>
                            </div>
                        ) : (
                            <div className="flex flex-col items-center pointer-events-none">
                                <Upload size={40} className="text-slate-300 group-hover:text-brand-500 mb-4 transition-colors" />
                                <span className="font-bold text-slate-700 text-lg mb-1">Click to upload or drag and drop</span>
                                <span className="text-slate-400 text-sm uppercase font-medium tracking-wide">
                                    {isVideoMode ? 'WEBM, MP4 (MAX. 100MB)' : 'PPT, PPTX, or PDF (MAX. 10MB)'}
                                </span>
                            </div>
                        )}
                    </div>

                    <div className="relative flex items-center py-2">
                        <div className="flex-grow border-t border-slate-200"></div>
                        <span className="flex-shrink-0 mx-4 text-slate-400 text-xs font-medium uppercase">Or Paste Text</span>
                        <div className="flex-grow border-t border-slate-200"></div>
                    </div>

                    {/* Text Area */}
                    <div>
                        <label className="block text-xs font-bold text-slate-700 mb-2">
                            {isVideoMode ? 'Video Transcript (Optional)' : 'Pitch Deck Text (Optional)'}
                        </label>
                        <textarea 
                            className="w-full h-32 p-4 rounded-xl border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none resize-none bg-slate-50 transition-all placeholder:text-slate-400"
                            placeholder={isVideoMode ? "Paste video transcript here to improve analysis accuracy..." : "Paste your pitch text here (optional)..."}
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            disabled={isAnalyzing}
                        />
                    </div>

                    {/* Action Button */}
                    <button 
                        onClick={handleAnalyze}
                        disabled={isAnalyzing}
                        className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 text-white shadow-lg transition-all transform active:scale-95 ${isAnalyzing ? 'bg-slate-400 cursor-not-allowed' : isVideoMode ? 'bg-slate-900 hover:bg-slate-800 shadow-slate-900/20' : 'bg-slate-600 hover:bg-slate-500 shadow-slate-600/20'}`}
                    >
                        {isAnalyzing ? (
                            <>
                                <Loader2 className="animate-spin" /> {status === 'PREPARING_INPUT' ? 'Preparing...' : 'Analyzing...'}
                            </>
                        ) : (
                            <>
                                {isVideoMode ? 'Analyze Video Explanation' : 'Run AI Analysis'}
                            </>
                        )}
                    </button>
                    
                    {round1Passed && !isVideoMode && !isAnalyzing && (
                        <div className="flex items-center gap-2 justify-center text-emerald-600 text-sm font-medium animate-in fade-in">
                            <CheckCircle2 size={16} /> Analysis passed. Proceed to next step.
                        </div>
                    )}
                 </div>
             )}
          </div>

          {/* RIGHT PANEL: Results & Chat */}
          <div className="w-1/2 bg-slate-50 p-8 overflow-y-auto flex flex-col gap-6">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm flex-1 flex flex-col p-8 relative overflow-hidden min-h-[500px]">
                  
                  {isAnalyzing && (
                      <div className="absolute inset-0 bg-white/90 z-20 flex flex-col items-center justify-center text-center p-8">
                          <Loader2 size={48} className="text-brand-500 animate-spin mb-6" />
                          <h3 className="text-xl font-bold text-slate-800 mb-2">Analyzing Submission</h3>
                          <p className="text-slate-500 max-w-xs">{status}...</p>
                      </div>
                  )}

                  {!analysisResult && !isAnalyzing && stage !== EvaluationStage.LIVE_QA && (
                      <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                          <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-6">
                              {isVideoMode ? <Video size={32} className="text-slate-400" /> : <FileText size={32} className="text-slate-400" />}
                          </div>
                          <h3 className="text-lg font-bold text-slate-900 mb-2">Waiting for Content</h3>
                          <p className="text-slate-500 max-w-xs">
                              Upload a file and run analysis to see results
                          </p>
                      </div>
                  )}

                  {/* PPT Results */}
                  {analysisResult && stage === EvaluationStage.PPT && (
                      <div className="animate-in slide-in-from-right-10 fade-in duration-500 space-y-8">
                           <div className="flex items-center justify-between">
                                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">AI Assessment Model</h3>
                           </div>
                           <div className="p-4 border border-dashed border-slate-200 rounded-xl bg-slate-50">
                                <ScoreVisualizer data={analysisResult} />
                           </div>
                           <div className="grid grid-cols-2 gap-4">
                               <div className="bg-emerald-50 p-5 rounded-xl border border-emerald-100">
                                   <h4 className="font-bold text-emerald-800 text-sm mb-3">Key Strengths</h4>
                                   <ul className="space-y-2">
                                       {analysisResult.key_strengths?.map((s, i) => (
                                           <li key={i} className="text-xs text-emerald-700 flex items-start gap-2">
                                               <CheckCircle2 size={12} className="mt-0.5 shrink-0" /> {s}
                                           </li>
                                       ))}
                                   </ul>
                               </div>
                               <div className={`p-5 rounded-xl border ${analysisResult.blocking_issues && analysisResult.blocking_issues.length > 0 ? 'bg-rose-50 border-rose-100' : 'bg-slate-50 border-slate-100'}`}>
                                   <h4 className={`font-bold text-sm mb-3 ${analysisResult.blocking_issues && analysisResult.blocking_issues.length > 0 ? 'text-rose-800' : 'text-slate-500'}`}>
                                       Blocking Issues
                                   </h4>
                                   {analysisResult.blocking_issues && analysisResult.blocking_issues.length > 0 ? (
                                       <ul className="space-y-2">
                                           {analysisResult.blocking_issues.map((s, i) => (
                                               <li key={i} className="text-xs text-rose-700 flex items-start gap-2">
                                                   <AlertTriangle size={12} className="mt-0.5 shrink-0" /> {s}
                                               </li>
                                           ))}
                                       </ul>
                                   ) : (
                                       <p className="text-xs text-slate-400 italic">No critical blocking issues detected.</p>
                                   )}
                               </div>
                           </div>
                           {analysisResult.readiness_recommendation === 'PASS' && (
                               <div className="p-4 bg-emerald-600 text-white rounded-xl shadow-lg shadow-emerald-900/10 flex items-center justify-between">
                                   <div className="flex items-center gap-3">
                                       <div className="bg-white/20 p-2 rounded-lg"><Award size={20} /></div>
                                       <div>
                                           <div className="font-bold">Round 1 Passed</div>
                                           <div className="text-xs text-emerald-100 opacity-90">Ready for Video & Demo</div>
                                       </div>
                                   </div>
                                   <button onClick={() => handleStageChange(EvaluationStage.VIDEO)} className="bg-white text-emerald-700 px-4 py-2 rounded-lg text-xs font-bold hover:bg-emerald-50 transition-colors">
                                       Next Step
                                   </button>
                               </div>
                           )}
                      </div>
                  )}

                  {/* Video Results */}
                  {analysisResult && stage === EvaluationStage.VIDEO && (
                      <div className="animate-in slide-in-from-right-10 fade-in duration-500 space-y-6">
                          <div>
                              <h3 className="text-lg font-bold text-slate-900">AI Analysis</h3>
                              <p className="text-slate-500 text-xs">Initial assessment before live interaction</p>
                          </div>
                          <div className="space-y-4">
                              <div>
                                  <h4 className="text-xs font-bold text-slate-900 mb-2">First Impression</h4>
                                  <p className="text-sm italic text-slate-600 border-l-2 border-slate-300 pl-4 py-1">
                                      "{analysisResult.first_impression}"
                                  </p>
                              </div>
                              <div>
                                  <h4 className="text-xs font-bold text-slate-900 mb-2">Brief Observation</h4>
                                  <p className="text-sm text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                                      {analysisResult.observation}
                                  </p>
                              </div>
                          </div>
                          {analysisResult.first_question && (
                              <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-5">
                                  <h4 className="font-bold text-indigo-800 text-sm mb-3 flex items-center gap-2">
                                      Suggested First Question
                                  </h4>
                                  <p className="text-indigo-700 font-medium text-lg mb-3">"{analysisResult.first_question.question_text}"</p>
                                  <div className="flex items-center gap-2">
                                      <span className="text-[10px] font-bold bg-white text-indigo-600 px-2 py-1 rounded border border-indigo-100 uppercase tracking-wider">Intent</span>
                                      <span className="text-xs text-indigo-600">{analysisResult.first_question.intent}</span>
                                  </div>
                              </div>
                          )}
                          <div className="pt-4 border-t border-slate-100 mt-auto">
                              <button 
                                  onClick={() => handleStageChange(EvaluationStage.LIVE_QA)}
                                  className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold text-sm hover:bg-slate-800 transition-colors"
                              >
                                  Complete Round 2 & Proceed to Q&A
                              </button>
                          </div>
                      </div>
                  )}

                  {/* LIVE QA: Chat / Voice Interface OR Results */}
                  {stage === EvaluationStage.LIVE_QA && (
                      !liveSessionFinished ? (
                          // Chat Interface
                          <div className="flex flex-col h-full animate-in fade-in">
                              <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-4">
                                  <div className="flex items-center gap-2 text-indigo-600">
                                      <Bot size={18} />
                                      <span className="font-bold text-sm">AI Interviewer</span>
                                  </div>
                                  <span className="text-xs text-slate-400">
                                      {inputMode === 'VOICE' ? 'Voice Mode Active' : 'Text Mode Active'}
                                  </span>
                              </div>

                              {/* Chat History Area */}
                              <div className="flex-1 overflow-y-auto mb-4 space-y-4 pr-2">
                                  {chatHistory.length === 0 && (
                                      <div className="flex flex-col items-center justify-center h-full text-slate-400 gap-4">
                                          <Bot size={48} className="text-slate-200" />
                                          <p className="text-sm">Ready to start the technical interview?</p>
                                          <button onClick={handleStartChat} className="px-6 py-2 bg-indigo-600 text-white rounded-full font-bold text-sm shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-colors">
                                              Begin Session
                                          </button>
                                      </div>
                                  )}
                                  {chatHistory.map((msg, i) => (
                                      <div key={i} className={`flex ${msg.role === 'ai' ? 'justify-start' : 'justify-end'}`}>
                                          <div className={`relative max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed shadow-sm group ${
                                              msg.role === 'ai' 
                                                ? 'bg-indigo-50 text-indigo-900 rounded-tl-none border border-indigo-100' 
                                                : 'bg-white text-slate-700 rounded-tr-none border border-slate-200'
                                          }`}>
                                              <p>{msg.text}</p>
                                              {msg.role === 'ai' && (
                                                  <button 
                                                    onClick={() => speakResponse(msg.text)}
                                                    className="absolute -right-8 top-2 p-1.5 text-slate-300 hover:text-indigo-600 rounded-full hover:bg-indigo-100 transition-colors opacity-0 group-hover:opacity-100"
                                                    title="Replay Audio"
                                                  >
                                                      <Volume2 size={16} />
                                                  </button>
                                              )}
                                          </div>
                                      </div>
                                  ))}
                                  {/* Typing Indicator */}
                                  {isChatProcessing && (
                                      <div className="flex justify-start">
                                          <div className="bg-indigo-50 p-4 rounded-2xl rounded-tl-none border border-indigo-100 flex items-center gap-1 h-12 w-16 justify-center">
                                              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" />
                                              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-100" />
                                              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce delay-200" />
                                          </div>
                                      </div>
                                  )}
                                  <div ref={chatEndRef} />
                              </div>

                              {/* Input Area */}
                              {chatHistory.length > 0 && (
                                  <div className="mt-auto">
                                      {inputMode === 'VOICE' && isVoiceSupported ? (
                                          <div className="flex flex-col items-center gap-4">
                                              <div className="relative">
                                                  {isListening && (
                                                      <div className="absolute inset-0 bg-rose-500 rounded-full animate-ping opacity-30"></div>
                                                  )}
                                                  <button 
                                                      onClick={toggleListening}
                                                      disabled={isAiSpeaking}
                                                      className={`w-16 h-16 rounded-full flex items-center justify-center shadow-lg transition-all ${
                                                          isAiSpeaking 
                                                            ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                                            : isListening 
                                                                ? 'bg-rose-600 text-white scale-110' 
                                                                : 'bg-slate-900 text-white hover:bg-slate-800'
                                                      }`}
                                                  >
                                                      {isListening ? <StopCircle size={24} /> : <Mic size={24} />}
                                                  </button>
                                              </div>
                                              <div className="text-center">
                                                  <p className={`text-sm font-bold ${
                                                      isAiSpeaking ? 'text-indigo-600' :
                                                      isListening ? 'text-rose-600 animate-pulse' : 'text-slate-500'
                                                  }`}>
                                                      {isAiSpeaking ? 'AI Speaking...' : isListening ? 'Listening...' : 'Tap to Speak'}
                                                  </p>
                                                  {chatInput && (
                                                      <p className="text-xs text-slate-400 mt-2 max-w-xs mx-auto italic truncate">
                                                          "{chatInput}"
                                                      </p>
                                                  )}
                                              </div>
                                              
                                              <div className="flex gap-2 w-full">
                                                   {chatInput && (
                                                       <button onClick={() => handleSendChat()} className="flex-1 py-3 bg-indigo-100 text-indigo-700 rounded-xl font-bold text-sm hover:bg-indigo-200 transition-colors">
                                                           Confirm & Send
                                                       </button>
                                                   )}
                                                   <button onClick={toggleInputMode} className="p-3 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors ml-auto">
                                                       <Keyboard size={20} />
                                                   </button>
                                              </div>
                                          </div>
                                      ) : (
                                          // Text Fallback
                                          <div className="flex flex-col gap-2">
                                              <div className="flex gap-2">
                                                  <input 
                                                      className="flex-1 p-3 border border-slate-300 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm"
                                                      placeholder="Type your answer here..."
                                                      value={chatInput}
                                                      onChange={(e) => setChatInput(e.target.value)}
                                                      onKeyDown={(e) => e.key === 'Enter' && handleSendChat()}
                                                  />
                                                  <button 
                                                      onClick={() => handleSendChat()}
                                                      disabled={!chatInput.trim()}
                                                      className="bg-indigo-600 text-white p-3 rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-md"
                                                  >
                                                      <Send size={20} />
                                                  </button>
                                              </div>
                                              <div className="flex justify-center">
                                                  <button onClick={toggleInputMode} className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 py-2">
                                                      {isVoiceSupported ? <><Mic size={12} /> Switch to Voice Input</> : <><MicOff size={12} /> Voice Not Available</>}
                                                  </button>
                                              </div>
                                          </div>
                                      )}
                                  </div>
                              )}
                          </div>
                      ) : (
                          // Results View
                          <div className="animate-in slide-in-from-right-10 fade-in duration-500 space-y-6">
                              <div className="flex items-center gap-2 mb-4">
                                  <div className="bg-emerald-100 p-2 rounded-lg">
                                      <CheckCircle2 className="text-emerald-600" size={24} />
                                  </div>
                                  <div>
                                      <h3 className="text-lg font-bold text-slate-900">Live Evaluation Complete</h3>
                                      <p className="text-slate-500 text-xs">AI Assessment based on Q&A transcript</p>
                                  </div>
                              </div>

                              {analysisResult && <ScoreVisualizer data={analysisResult} />}
                              
                              <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-5">
                                  <h4 className="font-bold text-indigo-800 text-sm mb-3">Assessment Summary</h4>
                                  <p className="text-indigo-900 text-sm leading-relaxed">
                                      {analysisResult?.summary}
                                  </p>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                   <div className="bg-white border border-slate-200 p-4 rounded-xl">
                                       <h5 className="font-bold text-emerald-600 text-xs uppercase mb-2">Strengths</h5>
                                       <ul className="space-y-2">
                                           {analysisResult?.key_strengths?.map((s, i) => (
                                               <li key={i} className="text-xs text-slate-600 flex items-start gap-2">
                                                   <CheckCircle2 size={12} className="mt-0.5 shrink-0 text-emerald-500" /> {s}
                                               </li>
                                           ))}
                                       </ul>
                                   </div>
                                   <div className="bg-white border border-slate-200 p-4 rounded-xl">
                                       <h5 className="font-bold text-rose-500 text-xs uppercase mb-2">Weaknesses</h5>
                                       <ul className="space-y-2">
                                           {analysisResult?.blocking_issues?.map((s, i) => (
                                               <li key={i} className="text-xs text-slate-600 flex items-start gap-2">
                                                   <AlertTriangle size={12} className="mt-0.5 shrink-0 text-rose-400" /> {s}
                                               </li>
                                           ))}
                                       </ul>
                                   </div>
                              </div>

                              <div className="pt-4 border-t border-slate-100 mt-auto">
                                  <button 
                                      onClick={() => navigate('/judge/reports')}
                                      className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold text-sm hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
                                  >
                                      View Final Report <ArrowRight size={16} />
                                  </button>
                              </div>
                          </div>
                      )
                  )}

              </div>
              
              {/* Certificate Card */}
              <div className={`rounded-xl border p-6 flex items-center justify-between transition-all ${
                  certificateUnlocked 
                  ? 'bg-white border-emerald-200 shadow-sm' 
                  : 'bg-slate-100 border-slate-200 opacity-75'
              }`}>
                  <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          certificateUnlocked ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-200 text-slate-400'
                      }`}>
                          {certificateUnlocked ? <CheckCircle2 size={24} /> : <Lock size={24} />}
                      </div>
                      <div>
                          <h3 className={`font-bold ${certificateUnlocked ? 'text-slate-900' : 'text-slate-500'}`}>
                              Participation Certificate
                          </h3>
                          <p className="text-xs text-slate-500">
                              {certificateUnlocked 
                                  ? "Evaluation complete. Certificate ready for download." 
                                  : "Complete all rounds to unlock your certificate."}
                          </p>
                      </div>
                  </div>
                  <button 
                      onClick={handleDownloadCertificate}
                      disabled={!certificateUnlocked}
                      className={`px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 transition-colors ${
                          certificateUnlocked
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-lg shadow-emerald-900/20'
                          : 'bg-slate-300 text-slate-500 cursor-not-allowed'
                      }`}
                  >
                      <Download size={16} /> Download PDF
                  </button>
              </div>
          </div>

      </div>
    </div>
  );
};

export default TeamPortalView;