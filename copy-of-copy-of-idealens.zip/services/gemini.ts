import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult, AnalysisStatus } from '../types';
import { MOCK_PPT_ANALYSIS, MOCK_VIDEO_ANALYSIS, SYSTEM_INSTRUCTION_PPT, SYSTEM_INSTRUCTION_VIDEO, SYSTEM_INSTRUCTION_QA } from '../constants';

// Declare process for TS (environment usually provides this)
declare var process: any;

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key not found in environment variables. Ensure process.env.API_KEY is set.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

// Helper to clean Markdown from JSON string
const cleanJSON = (text: string): string => {
  let cleaned = text.trim();
  // Remove markdown wrapping if present
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return cleaned;
};

// Strict Schema for Round 2A Video Trigger
const videoTriggerSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    status: { type: Type.STRING, enum: ["READY", "BLOCKED"] },
    message: { type: Type.STRING },
    first_impression: { type: Type.STRING },
    brief_observation: { type: Type.STRING },
    key_moments: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          timestamp: { type: Type.STRING },
          description: { type: Type.STRING }
        }
      }
    },
    next_question: {
      type: Type.OBJECT,
      properties: {
        question: { type: Type.STRING },
        intent: { type: Type.STRING }
      },
    }
  },
  required: ["status"]
};

// Strict Schema for Round 1 PPT Gate
const pptAnalysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    status: { type: Type.STRING, enum: ["READY", "BLOCKED"] },
    scores: {
      type: Type.OBJECT,
      properties: {
        clarity: { type: Type.NUMBER },
        structure: { type: Type.NUMBER },
        completeness: { type: Type.NUMBER },
        readability: { type: Type.NUMBER },
        overall: { type: Type.NUMBER }
      },
    },
    recommendation: { type: Type.STRING, enum: ["PASS", "HOLD"] },
    key_strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
    blocking_issues: { type: Type.ARRAY, items: { type: Type.STRING } },
    message: { type: Type.STRING }
  },
  required: ["status"]
};

// Schema for Live Session Scoring
const liveSessionSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    technical_depth_score: { type: Type.NUMBER, description: "0-10 score on technical knowledge" },
    clarity_score: { type: Type.NUMBER, description: "0-10 score on communication clarity" },
    reasoning_score: { type: Type.NUMBER, description: "0-10 score on logical consistency" },
    confidence_score: { type: Type.NUMBER, description: "0-10 score on answer confidence/completeness" },
    overall_score: { type: Type.NUMBER },
    recommendation: { type: Type.STRING, enum: ["PASS", "REVIEW", "FAIL"] },
    strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
    weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
    summary: { type: Type.STRING }
  },
  required: ["technical_depth_score", "clarity_score", "reasoning_score", "overall_score", "recommendation"]
};

export const analyzeSubmission = async (
  textInput: string,
  fileInput: File | null,
  mode: 'PPT' | 'VIDEO',
  isDemoMode: boolean,
  onStatusUpdate?: (status: AnalysisStatus) => void
): Promise<AnalysisResult> => {
  
  const updateStatus = (status: AnalysisStatus) => {
      if (onStatusUpdate) onStatusUpdate(status);
  };

  if (isDemoMode) {
    // Optimized timing for snappier demo feel
    if (mode === 'VIDEO') {
        updateStatus('EXTRACTING_VIDEO');
        await new Promise(resolve => setTimeout(resolve, 800)); // Reduced from 1500
        updateStatus('SUMMARIZING_TRANSCRIPT');
        await new Promise(resolve => setTimeout(resolve, 600)); // Reduced from 1200
    } else {
        updateStatus('PREPARING_INPUT');
        await new Promise(resolve => setTimeout(resolve, 500)); // Reduced from 800
    }
    
    updateStatus('CALLING_GEMINI');
    await new Promise(resolve => setTimeout(resolve, 800)); // Reduced from 1500
    updateStatus('PROCESSING_RESPONSE');
    await new Promise(resolve => setTimeout(resolve, 400)); // Reduced from 600
    updateStatus('READY');
    return mode === 'VIDEO' ? MOCK_VIDEO_ANALYSIS : MOCK_PPT_ANALYSIS;
  }

  const ai = getClient();
  if (!ai) {
    updateStatus('ERROR');
    return mode === 'VIDEO' ? MOCK_VIDEO_ANALYSIS : MOCK_PPT_ANALYSIS;
  }

  const modelId = 'gemini-3-flash-preview';
  const instruction = mode === 'PPT' ? SYSTEM_INSTRUCTION_PPT : SYSTEM_INSTRUCTION_VIDEO;
  const targetSchema = mode === 'PPT' ? pptAnalysisSchema : videoTriggerSchema;

  try {
    let contentsPayload: any = { parts: [] };

    // 1. HANDLE FILE INPUT (Multimodal)
    if (fileInput) {
        // Validate MIME Types
        if (mode === 'PPT') {
             updateStatus('PREPARING_INPUT'); // Standard for PPT
            if (fileInput.type !== 'application/pdf') {
                updateStatus('BLOCKED');
                return {
                    status: 'BLOCKED',
                    message: 'Invalid file format for PPT Review.',
                    instruction: 'Please upload a PDF version of your deck. Raw PPTX files are not supported directly.',
                    problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0
                };
            }
        } else if (mode === 'VIDEO') {
             updateStatus('EXTRACTING_VIDEO'); // Specific for Video
             if (!fileInput.type.startsWith('video/')) {
                updateStatus('BLOCKED');
                return {
                    status: 'BLOCKED',
                    message: 'Invalid file format.',
                    instruction: 'Please upload a video file (MP4, WEBM, MOV).',
                    problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0
                };
             }
        }

        // Limit File Size (Client-side safety, ~20MB)
        if (fileInput.size > 20 * 1024 * 1024) {
             updateStatus('BLOCKED');
             return {
                 status: 'BLOCKED',
                 message: 'File too large.',
                 instruction: 'Please upload a file smaller than 20MB or provide a text summary/link.',
                 problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0
             };
        }

        const base64Data = await fileToBase64(fileInput);
        contentsPayload.parts.push({
            inlineData: {
                mimeType: fileInput.type,
                data: base64Data
            }
        });
    }

    // 2. HANDLE TEXT INPUT
    if (textInput && textInput.trim()) {
         if (mode === 'VIDEO') {
             updateStatus('SUMMARIZING_TRANSCRIPT');
             // Fast track text processing
             await new Promise(resolve => setTimeout(resolve, 300));
         }

         let safeText = textInput;
         // Truncate text if it's very long (keeping some safety buffer)
         if (safeText.length > 10000) {
             safeText = safeText.substring(0, 10000) + "...[TRUNCATED]";
         }
         
         const label = mode === 'PPT' ? "Pitch Deck Text/Notes:" : "Video Transcript/Context:";
         contentsPayload.parts.push({ text: `${label}\n${safeText}` });
    }

    // 3. CHECK FOR EMPTY PAYLOAD
    if (contentsPayload.parts.length === 0) {
        updateStatus('BLOCKED');
        return {
            status: 'BLOCKED',
            message: 'No content provided.',
            instruction: 'Please upload a file (PDF/Video) or paste text content.',
            problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0
        };
    }

    // Add prompt instruction to the payload parts
    contentsPayload.parts.push({ text: mode === 'PPT' ? "Analyze this submission material." : "Analyze this video/content." });

    updateStatus('CALLING_GEMINI');

    // Extended timeout for multimodal processing (5 minutes / 300s)
    const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error("TIMEOUT")), 300000)
    );

    const apiCallPromise = ai.models.generateContent({
      model: modelId,
      contents: contentsPayload,
      config: {
        systemInstruction: instruction,
        responseMimeType: "application/json",
        responseSchema: targetSchema,
        thinkingConfig: { thinkingBudget: 0 } 
      }
    });

    const response: any = await Promise.race([apiCallPromise, timeoutPromise]);

    updateStatus('PROCESSING_RESPONSE');
    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const json = JSON.parse(cleanJSON(text));

    // MAPPING LAYER
    if (mode === 'PPT') {
        if (json.status === 'BLOCKED') {
             updateStatus('BLOCKED');
             return {
                 status: 'BLOCKED',
                 message: json.message || 'Analysis Blocked',
                 instruction: 'Please provide clearer content.',
                 problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0
             };
        }

        updateStatus('READY');
        return {
            problem_clarity: json.scores?.clarity || 0,
            problem_clarity_reason: "Based on AI analysis of the document/text.",
            solution_structure: json.scores?.structure || 0,
            solution_structure_reason: "Based on logical flow analysis.",
            completeness: json.scores?.completeness || 0,
            completeness_reason: "Based on section completeness.",
            readability: json.scores?.readability || 0,
            readability_reason: "Based on content presentation.",
            overall_assistive_score: json.scores?.overall || 0,
            readiness_recommendation: json.recommendation,
            reason_for_recommendation: json.recommendation === 'PASS' 
                ? "Content meets clarity and structure requirements." 
                : "Content is missing key elements or is unclear.",
            key_strengths: json.key_strengths || [],
            blocking_issues: json.blocking_issues || [],
            summary: "Analysis complete."
        };
    } else {
        // VIDEO Mode
        if (json.status === 'BLOCKED') {
            updateStatus('BLOCKED');
        } else {
            updateStatus('READY');
        }
        
        return {
            problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0,
            status: json.status,
            first_impression: json.first_impression,
            observation: json.brief_observation,
            key_moments: json.key_moments || [],
            first_question: json.next_question ? {
                question_text: json.next_question.question,
                intent: json.next_question.intent
            } : undefined,
            message: json.message,
            instruction: json.status === 'BLOCKED' ? 'Please provide a valid video or clearer notes.' : undefined,
            summary: json.status === 'BLOCKED' ? json.message : json.brief_observation
        };
    }

  } catch (error: any) {
    console.error("Gemini Analysis Error:", error);
    updateStatus('ERROR');
    
    const isTimeout = error.message === 'TIMEOUT';
    const isModelError = error.message?.includes('model not found') || error.message?.includes('404');
    
    let errMessage = "Service unavailable.";
    let errInstruction = "Please try again.";

    if (isTimeout) {
        errMessage = "Analysis timed out (server took too long).";
        errInstruction = "The file might be too complex for real-time analysis. Try a smaller file or shorter video.";
    } else if (isModelError) {
        errMessage = "AI Model not found.";
        errInstruction = "Contact support.";
    }

    return {
        status: 'BLOCKED',
        error: isTimeout ? 'TIMEOUT' : 'API_ERROR',
        message: errMessage,
        instruction: errInstruction,
        problem_clarity: 0, solution_structure: 0, completeness: 0, readability: 0, overall_assistive_score: 0
    };
  }
};

export const generateQuestion = async (context: string, history: {role: string, text: string}[], isDemoMode: boolean): Promise<string> => {
    if (isDemoMode) {
        await new Promise(resolve => setTimeout(resolve, 800)); // Faster QA generation
        return "Given your blockchain approach, how do you handle gas fees for micro-transactions in the supply chain?";
    }

    const ai = getClient();
    if (!ai) return "Error: API Key missing.";

    const modelId = 'gemini-3-flash-preview';

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: {
                parts: [
                    { text: `Project Context: ${context}` },
                    ...history.map(h => ({ text: `${h.role === 'user' ? 'Judge/Team' : 'Interviewer'}: ${h.text}` })),
                    { text: "Generate the next follow-up interview question." }
                ]
            },
            config: {
                systemInstruction: SYSTEM_INSTRUCTION_QA,
            }
        });
        return response.text || "Could not generate question.";
    } catch (e) {
        console.error(e);
        return "System Error: Unable to generate question.";
    }
}

// --- NEW ROUND 2 INTERVIEW LOGIC ---
export const generateInterviewQuestion = async (
  history: {role: 'ai' | 'user', text: string}[],
  context: string
): Promise<string> => {
    const ai = getClient();
    // Fallback for demo mode if no key (though key is usually required for this app)
    if (!ai) return "SESSION_COMPLETE"; 

    const modelId = 'gemini-3-flash-preview';
    
    // Construct prompt
    const prompt = `
    Context: ${context}
    
    You are an AI Interviewer for a Hackathon (Round 2).
    Your goal is to verify the team's technical depth and implementation details.
    
    Current Conversation History:
    ${history.map(h => `${h.role === 'ai' ? 'Interviewer' : 'Candidate'}: ${h.text}`).join('\n')}
    
    Task: Generate the NEXT follow-up question.
    Rules:
    1. Be professional, concise, and direct (max 2 sentences).
    2. Ask about technical challenges, architecture, or scalability based on their previous answer.
    3. Do NOT repeat questions.
    4. If the history contains 3 or more Q&A pairs (3 User answers), output exactly: "SESSION_COMPLETE"
    `;

    try {
        const response = await ai.models.generateContent({
            model: modelId,
            contents: { parts: [{ text: prompt }] },
            config: { thinkingConfig: { thinkingBudget: 0 } }
        });
        return response.text?.trim() || "Could you elaborate on that technical aspect?";
    } catch (e) {
        console.error("Interview Gen Error", e);
        return "Could you describe your tech stack in more detail?";
    }
}

export const generateLiveSessionScores = async (
    history: {role: 'ai' | 'user', text: string}[],
    context: string,
    isDemoMode: boolean
): Promise<AnalysisResult> => {
    
    if (isDemoMode) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        return {
            problem_clarity: 8.5, // Technical Depth
            problem_clarity_reason: "Demonstrated strong understanding of backend scaling.",
            solution_structure: 9.0, // Reasoning
            solution_structure_reason: "Logical responses with clear cause-and-effect explanations.",
            completeness: 8.8, // Confidence
            completeness_reason: "Answers were direct and confident.",
            readability: 9.2, // Clarity
            readability_reason: "Spoken communication was clear and concise.",
            overall_assistive_score: 8.9,
            readiness_recommendation: 'PASS',
            key_strengths: ["Strong architectural knowledge", "Clear verbal communication"],
            blocking_issues: [],
            summary: "Candidate performed well in the live technical Q&A."
        } as AnalysisResult;
    }

    const ai = getClient();
    if (!ai) throw new Error("API Key Missing");

    const modelId = 'gemini-3-flash-preview';
    const transcript = history.map(h => `${h.role.toUpperCase()}: ${h.text}`).join('\n');

    const prompt = `
    Context: ${context}
    
    Transcript of Live Technical Q&A:
    ${transcript}
    
    Task: Evaluate the candidate's performance based on this interview.
    Generate numeric scores (0-10) and specific feedback.
    `;

    const response = await ai.models.generateContent({
        model: modelId,
        contents: { parts: [{ text: prompt }] },
        config: {
            responseMimeType: "application/json",
            responseSchema: liveSessionSchema,
            thinkingConfig: { thinkingBudget: 0 }
        }
    });

    const text = response.text;
    if (!text) throw new Error("No response");
    const json = JSON.parse(cleanJSON(text));

    // Map to AnalysisResult interface to reuse visualizers
    return {
        // Mapping Live Scores to existing fields for visualization compatibility
        problem_clarity: json.technical_depth_score || 0, 
        problem_clarity_reason: "Technical Knowledge & Depth",
        
        solution_structure: json.reasoning_score || 0,
        solution_structure_reason: "Logic & Problem Solving",
        
        completeness: json.confidence_score || 0,
        completeness_reason: "Confidence & Completeness",
        
        readability: json.clarity_score || 0,
        readability_reason: "Communication Clarity",

        overall_assistive_score: json.overall_score || 0,
        
        readiness_recommendation: json.recommendation === 'PASS' ? 'PASS' : 'HOLD',
        reason_for_recommendation: json.summary,
        
        key_strengths: json.strengths || [],
        blocking_issues: json.weaknesses || [],
        summary: json.summary
    } as AnalysisResult;
};

// Helper
const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // remove data:mime/type;base64, prefix
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = error => reject(error);
  });
};