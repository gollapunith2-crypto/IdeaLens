
export interface Team {
  id: string;
  name: string;
  projectTitle: string;
  description: string;
  status: 'pending' | 'reviewed' | 'live';
  submittedAt: string;
  isShortlisted?: boolean;
  
  // Dashboard Analytics Fields
  overallScore?: number; // 0-10
  currentStage?: 'Round 1 (PPT)' | 'Round 2 (Video)' | 'Round 3 (Live)';
  lastUpdated?: string;
  
  // Media
  videoUrl?: string;
}

export type AnalysisStatus = 
  | 'IDLE' 
  | 'EXTRACTING_VIDEO'       // Step 1 for Video
  | 'SUMMARIZING_TRANSCRIPT' // Step 2 for Video
  | 'PREPARING_INPUT' 
  | 'CALLING_GEMINI' 
  | 'PROCESSING_RESPONSE' 
  | 'BLOCKED' 
  | 'READY' 
  | 'ERROR';

export interface AnalysisResult {
  problem_clarity: number;
  problem_clarity_reason?: string;
  
  solution_structure: number;
  solution_structure_reason?: string;
  
  completeness: number;
  completeness_reason?: string;
  
  readability: number;
  readability_reason?: string;

  overall_assistive_score: number;
  confidence_score?: number; // 0-100

  // Round 1 PPT Specifics
  readiness_recommendation?: 'PASS' | 'HOLD';
  reason_for_recommendation?: string;
  blocking_issues?: string[];

  // Round 2A Video Trigger Specifics
  status?: 'READY' | 'BLOCKED';
  error?: string;
  message?: string;
  instruction?: string;
  
  first_impression?: string;
  observation?: string;
  key_moments?: { timestamp: string; description: string }[]; // New field for video analysis
  first_question?: {
    question_text: string;
    intent: string;
  };
  next_question?: {
    question_text: string;
    intent: string;
  };

  // Round 2 Specifics (Future/Scoring)
  alignment_score?: number;
  communication_score?: number;

  key_strengths?: string[];
  areas_for_improvement?: string[];
  summary?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model'; // 'user' is the judge/team context
  text: string;
  timestamp: number;
}

export enum EvaluationStage {
  PPT = 'PPT',
  VIDEO = 'VIDEO',
  LIVE_QA = 'LIVE_QA',
  FEEDBACK = 'FEEDBACK'
}
